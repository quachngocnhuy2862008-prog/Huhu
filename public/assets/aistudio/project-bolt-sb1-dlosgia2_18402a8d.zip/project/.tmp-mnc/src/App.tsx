import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  ArrowLeftRight,
  Award,
  BookmarkPlus,
  Columns2,
  History,
  Loader2,
  Palette,
  Send,
  Shirt,
  Sparkles,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {
  ActiveDockTab,
  BodyMeasurements,
  CameraPresetId,
  EulerDegrees,
  GenderProfile,
  HairstyleId,
  JointId,
  JointRotationMap,
  OutfitConfiguration,
  OutfitHistoryEntry,
  PoseAiGenerationResult,
  PosePresetId,
  StudioLightingId,
  WeatherEffectConfig,
} from './types/studio';
import {
  analyzeAndTransformUploadedGarment,
  analyzeBodyAndGarmentFit,
  BOTTOM_STYLES,
  CROQUIS_SIGNATURE_ROTATIONS,
  DEFAULT_BODY_MEASUREMENTS,
  DEFAULT_OUTFIT,
  DEFAULT_WEATHER_EFFECT,
  deriveMeasurementsFromHeightWeight,
  EYE_LENS_SWATCHES,
  generatePoseFromNaturalLanguage,
  getUploadMatchedOutfitRecommendations,
  HAIR_COLOR_SWATCHES,
  HAIRSTYLE_OPTIONS,
  LIPSTICK_SWATCHES,
  MAKEUP_PRESETS,
  OUTERWEAR_STYLES,
  POSE_AI_SUGGESTION_PROMPTS,
  POSE_PRESETS,
  SUGGESTED_OUTFIT_PRESETS,
  synthesizeColorPalettesFromOutfit,
  TOP_STYLES,
  ZERO_JOINT_ROTATIONS,
} from './data/presets';
import { TopStudioBar } from './components/TopStudioBar';
import { MannequinViewport } from './components/MannequinViewport';
import { BottomControlDock } from './components/BottomControlDock';

const TEMP_HISTORY_STORAGE_KEY = 'smart_wardrobe_temp_outfit_history_v1';

function cloneOutfitConfig(cfg: OutfitConfiguration): OutfitConfiguration {
  return {
    selectedSize: cfg.selectedSize,
    hideAllGarments: cfg.hideAllGarments,
    top: {
      ...cfg.top,
      uploadedCutoutParams: cfg.top.uploadedCutoutParams
        ? [...cfg.top.uploadedCutoutParams]
        : undefined,
    },
    outerwear: {
      ...cfg.outerwear,
      uploadedCutoutParams: cfg.outerwear.uploadedCutoutParams
        ? [...cfg.outerwear.uploadedCutoutParams]
        : undefined,
    },
    bottom: {
      ...cfg.bottom,
      uploadedCutoutParams: cfg.bottom.uploadedCutoutParams
        ? [...cfg.bottom.uploadedCutoutParams]
        : undefined,
    },
    footwear: { ...cfg.footwear },
    accessories: cfg.accessories
      ? {
          watch: { ...cfg.accessories.watch },
          handbag: { ...cfg.accessories.handbag },
          sunglasses: { ...cfg.accessories.sunglasses },
        }
      : undefined,
  };
}

function summarizeOutfitLabel(cfg: OutfitConfiguration): string {
  if (cfg.hideAllGarments) return 'Không mặc trang phục';
  const parts: string[] = [];
  if (cfg.outerwear.styleId !== 'none') {
    const owName =
      cfg.outerwear.transformedSummary ||
      OUTERWEAR_STYLES.find((o) => o.id === cfg.outerwear.styleId)?.name ||
      'Áo khoác';
    parts.push(owName);
  }
  if (cfg.top.styleId !== 'none') {
    const topName =
      cfg.top.transformedSummary ||
      TOP_STYLES.find((t) => t.id === cfg.top.styleId)?.name ||
      'Áo';
    parts.push(topName);
  }
  if (cfg.bottom.styleId !== 'none') {
    const botName =
      cfg.bottom.transformedSummary ||
      BOTTOM_STYLES.find((b) => b.id === cfg.bottom.styleId)?.name ||
      'Quần/Váy';
    parts.push(botName);
  }
  return parts.length > 0 ? parts.slice(0, 2).join(' + ') : 'Phối đồ cơ bản';
}

export default function App() {
  const [activeTab, setActiveTab] = useState<ActiveDockTab>('body');
  const [isDockCollapsed, setIsDockCollapsed] = useState<boolean>(true);

  // 1. User Body Measurements State
  const [body, setBody] = useState<BodyMeasurements>(DEFAULT_BODY_MEASUREMENTS);

  // 2. Multi-Layer Outfit & PBR Fabric State
  const [outfit, setOutfit] = useState<OutfitConfiguration>(DEFAULT_OUTFIT);

  // 2b. Temporary Outfit History Memory State (for quick comparison)
  const [outfitHistory, setOutfitHistory] = useState<OutfitHistoryEntry[]>(
    () => {
      try {
        const raw = sessionStorage.getItem(TEMP_HISTORY_STORAGE_KEY);
        if (raw) {
          const parsed = JSON.parse(raw);
          if (Array.isArray(parsed)) return parsed;
        }
      } catch {
        // Ignore sessionStorage errors
      }
      return [];
    }
  );
  const [activeHistoryId, setActiveHistoryId] = useState<string | null>(null);
  const [activeHistoryIdB, setActiveHistoryIdB] = useState<string | null>(null);
  const [isSplitCompareMode, setIsSplitCompareMode] = useState<boolean>(false);
  const [compareOutfitB, setCompareOutfitB] =
    useState<OutfitConfiguration | null>(null);

  // 3. Pose Preset & 17-Joint Euler Rotation State (Default: Symmetric T-Pose centered in viewport)
  const [posePreset, setPosePreset] = useState<PosePresetId>('stand_still');
  const [selectedJoint, setSelectedJoint] = useState<JointId>('rightShoulder');
  const [jointRotations, setJointRotations] = useState<JointRotationMap>(() => ({
    ...ZERO_JOINT_ROTATIONS,
  }));

  // 4. Camera & Studio Lighting Presets
  const [cameraPreset, setCameraPreset] = useState<CameraPresetId>('full_front');
  const [cameraResetTrigger, setCameraResetTrigger] = useState<number>(0);
  const [lightingPreset, setLightingPreset] =
    useState<StudioLightingId>('daylight_studio');
  const [showMeasurementTape, setShowMeasurementTape] = useState<boolean>(false);
  const [isArMode, setIsArMode] = useState<boolean>(false);
  const [isQuickUploading, setIsQuickUploading] = useState<boolean>(false);
  const quickUploadRef = useRef<HTMLInputElement | null>(null);

  // 5. Environmental Weather Effects (Wind & Rain) & Pose AI Generator State
  const [weatherEffect, setWeatherEffect] = useState<WeatherEffectConfig>(
    DEFAULT_WEATHER_EFFECT
  );
  const [isGeneratingPose, setIsGeneratingPose] = useState<boolean>(false);
  const [lastAiPoseResult, setLastAiPoseResult] =
    useState<PoseAiGenerationResult | null>(null);
  const [quickPosePrompt, setQuickPosePrompt] = useState<string>('');

  // 6. Triggers for Video Walkthrough 360°, 3D Model Export (.GLB / .USDZ), and Outfit History Drawer
  const [videoWalkthroughTrigger, setVideoWalkthroughTrigger] =
    useState<number>(0);
  const [exportGlbTrigger, setExportGlbTrigger] = useState<number>(0);
  const [exportUsdzTrigger, setExportUsdzTrigger] = useState<number>(0);
  const [isHistoryModalOpen, setIsHistoryModalOpen] = useState<boolean>(false);

  const quickColorPalettes = useMemo(
    () => synthesizeColorPalettesFromOutfit(outfit),
    [outfit]
  );

  const quickUploadRecommendations = useMemo(
    () => getUploadMatchedOutfitRecommendations(outfit, body.genderProfile),
    [outfit, body.genderProfile]
  );

  const hasUploadedPiece = Boolean(
    outfit.outerwear.uploadedName ||
      outfit.outerwear.transformedSummary ||
      outfit.top.uploadedName ||
      outfit.top.transformedSummary ||
      outfit.bottom.uploadedName ||
      outfit.bottom.transformedSummary
  );

  const handleUpdateHeightWeight = useCallback(
    (heightCm: number, weightKg: number, nextGender?: GenderProfile) => {
      const clampedH = Math.min(300, Math.max(100, heightCm));
      const clampedW = Math.min(500, Math.max(20, weightKg));

      setBody((prev) => {
        const isGenderChanged = nextGender && nextGender !== prev.genderProfile;
        const gender = nextGender ?? prev.genderProfile;

        const targetHeight = isGenderChanged
          ? gender === 'male'
            ? 178
            : gender === 'female'
            ? 168
            : 173
          : clampedH;
        const targetWeight = isGenderChanged
          ? gender === 'male'
            ? 72
            : gender === 'female'
            ? 52
            : 62
          : clampedW;

        const nextHairstyle = isGenderChanged
          ? gender === 'male'
            ? 'mushroom_cut'
            : gender === 'female'
            ? 'long_wavy'
            : 'shoulder_bob'
          : prev.hairstyleId;

        const derived = deriveMeasurementsFromHeightWeight(
          targetHeight,
          targetWeight,
          gender
        );
        return {
          ...prev,
          genderProfile: gender,
          heightCm: targetHeight,
          weightKg: targetWeight,
          hairstyleId: nextHairstyle,
          ...derived,
        };
      });

      if (nextGender === 'male') {
        setOutfit((prev) => ({
          ...prev,
          top: {
            styleId: 'oxford_shirt',
            fabric: 'cotton',
            colorHex: '#F8FAFC',
            fitEase: 'regular',
          },
          outerwear: {
            styleId: 'none',
            fabric: 'fleece',
            colorHex: '#1E293B',
            fitEase: 'regular',
          },
          bottom: {
            styleId: 'male_dress_trousers',
            fabric: 'fleece',
            colorHex: '#1E293B',
            fitEase: 'regular',
          },
          footwear: {
            styleId: 'penny_loafers',
            colorHex: '#78350F',
          },
          selectedSize: 'L',
        }));
      } else if (nextGender === 'female') {
        setOutfit((prev) => ({
          ...prev,
          top: {
            styleId: 'silk_blouse_bow',
            fabric: 'silk',
            colorHex: '#F3EFE6',
            fitEase: 'slim',
          },
          outerwear: {
            styleId: 'none',
            fabric: 'fleece',
            colorHex: '#1E293B',
            fitEase: 'regular',
          },
          bottom: {
            styleId: 'slim_jeans',
            fabric: 'denim',
            colorHex: '#2B4C7E',
            fitEase: 'slim',
          },
          footwear: {
            styleId: 'minimal_sneakers',
            colorHex: '#F8FAFC',
          },
          selectedSize: 'S',
        }));
      }
    },
    []
  );

  const handleUpdateBodyField = useCallback(
    <K extends keyof BodyMeasurements>(key: K, value: BodyMeasurements[K]) => {
      setBody((prev) => ({
        ...prev,
        [key]: value,
      }));
    },
    []
  );

  const handleSelectPosePreset = useCallback((presetId: PosePresetId) => {
    setPosePreset(presetId);
    setLastAiPoseResult(null);
    const found = POSE_PRESETS.find((p) => p.id === presetId);
    if (found) {
      setJointRotations({ ...found.rotations });
    }
  }, []);

  const handleGenerateAiPose = useCallback(
    async (promptText: string) => {
      if (!promptText.trim()) return;
      setIsGeneratingPose(true);
      try {
        const res = await generatePoseFromNaturalLanguage(
          promptText,
          body.genderProfile
        );
        setLastAiPoseResult(res);
        setJointRotations({ ...res.rotations });
        // Use natural_idle for static/seated AI poses, catwalk_walk for catwalk, or greeting_wave for wave
        const norm = promptText.toLowerCase();
        if (norm.includes('catwalk') && !res.isSeated) {
          setPosePreset('catwalk_walk');
        } else if ((norm.includes('vẫy tay') || norm.includes('wave')) && !res.isSeated) {
          setPosePreset('greeting_wave');
        } else {
          setPosePreset('natural_idle');
        }
      } catch (err) {
        console.error('Pose AI error:', err);
      } finally {
        setIsGeneratingPose(false);
      }
    },
    [body.genderProfile]
  );

  const handleUpdateJointRotation = useCallback(
    (joint: JointId, nextEuler: EulerDegrees) => {
      setJointRotations((prev) => ({
        ...prev,
        [joint]: nextEuler,
      }));
    },
    []
  );

  const handleSelectJointFrom3D = useCallback((joint: JointId) => {
    setSelectedJoint(joint);
    setActiveTab('pose');
    setIsDockCollapsed(false);
  }, []);

  const handleResetCurrentJoint = useCallback(() => {
    setJointRotations((prev) => ({
      ...prev,
      [selectedJoint]: { ...CROQUIS_SIGNATURE_ROTATIONS[selectedJoint] },
    }));
  }, [selectedJoint]);

  const handleStandStillPose = useCallback(() => {
    setPosePreset('stand_still');
    setLastAiPoseResult(null);
    setJointRotations({ ...ZERO_JOINT_ROTATIONS });
    setCameraPreset('full_front');
    setCameraResetTrigger((c) => c + 1);
  }, []);

  const handleSelectCameraPreset = useCallback((nextCam: CameraPresetId) => {
    setCameraPreset(nextCam);
    setCameraResetTrigger((c) => c + 1);
  }, []);

  const handleQuickGarmentUpload = async (
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsQuickUploading(true);
    try {
      const res = await analyzeAndTransformUploadedGarment(
        file,
        undefined,
        body.genderProfile
      );
      setOutfit((prev) => {
        if (res.targetCategory === 'outerwear') {
          return {
            ...prev,
            hideAllGarments: false,
            outerwear: {
              ...prev.outerwear,
              styleId: res.outerwearStyleId,
              colorHex: res.colorHex,
              secondaryColorHex: res.secondaryColorHex,
              fabric: res.detectedFabric,
              weavePattern: res.weavePattern,
              fitEase: res.detectedFitEase,
              uploadedName: res.fileName,
              transformedSummary: res.transformedSummary,
              previewThumbUrl: res.previewThumbUrl,
              uploadedTextureUrl: res.uploadedTextureUrl,
              uploadedCutoutParams: res.uploadedCutoutParams,
            },
          };
        }
        if (res.targetCategory === 'bottom') {
          return {
            ...prev,
            hideAllGarments: false,
            bottom: {
              ...prev.bottom,
              styleId: res.bottomStyleId,
              colorHex: res.colorHex,
              secondaryColorHex: res.secondaryColorHex,
              fabric: res.detectedFabric,
              weavePattern: res.weavePattern,
              fitEase: res.detectedFitEase,
              uploadedName: res.fileName,
              transformedSummary: res.transformedSummary,
              previewThumbUrl: res.previewThumbUrl,
              uploadedTextureUrl: res.uploadedTextureUrl,
              uploadedCutoutParams: res.uploadedCutoutParams,
            },
          };
        }
        return {
          ...prev,
          hideAllGarments: false,
          top: {
            ...prev.top,
            styleId: res.topStyleId,
            colorHex: res.colorHex,
            secondaryColorHex: res.secondaryColorHex,
            fabric: res.detectedFabric,
            weavePattern: res.weavePattern,
            fitEase: res.detectedFitEase,
            uploadedName: res.fileName,
            transformedSummary: res.transformedSummary,
            previewThumbUrl: res.previewThumbUrl,
            uploadedTextureUrl: res.uploadedTextureUrl,
            uploadedCutoutParams: res.uploadedCutoutParams,
          },
        };
      });
    } catch (err) {
      console.error('Quick garment upload error:', err);
    } finally {
      setIsQuickUploading(false);
      if (quickUploadRef.current) {
        quickUploadRef.current.value = '';
      }
    }
  };

  const fitAnalysis = useMemo(
    () => analyzeBodyAndGarmentFit(body, outfit),
    [body, outfit]
  );

  const score = fitAnalysis.outfitScore;

  // Sync temporary outfit history to sessionStorage
  useEffect(() => {
    try {
      sessionStorage.setItem(
        TEMP_HISTORY_STORAGE_KEY,
        JSON.stringify(outfitHistory)
      );
    } catch {
      // Ignore quota exceeded if large uploaded textures are present; keep in-memory state
    }
  }, [outfitHistory]);

  const handleSaveCurrentOutfit = useCallback(() => {
    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const ss = String(now.getSeconds()).padStart(2, '0');
    const id = `outfit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const entry: OutfitHistoryEntry = {
      id,
      label: summarizeOutfitLabel(outfit),
      timestamp: `${hh}:${mm}:${ss}`,
      genderProfile: body.genderProfile,
      outfit: cloneOutfitConfig(outfit),
      score: { ...fitAnalysis.outfitScore },
    };
    setOutfitHistory((prev) => [entry, ...prev].slice(0, 12));
    setActiveHistoryId(id);
  }, [outfit, body.genderProfile, fitAnalysis.outfitScore]);

  const handleApplyHistoryEntry = useCallback((entry: OutfitHistoryEntry) => {
    setOutfit(cloneOutfitConfig(entry.outfit));
    setActiveHistoryId(entry.id);
  }, []);

  const handleSelectCompareHistoryB = useCallback(
    (entry: OutfitHistoryEntry) => {
      setCompareOutfitB(cloneOutfitConfig(entry.outfit));
      setActiveHistoryIdB(entry.id);
      setIsArMode(false);
      setIsSplitCompareMode(true);
    },
    []
  );

  const handleToggleSplitCompareMode = useCallback(() => {
    setIsSplitCompareMode((prev) => {
      const next = !prev;
      if (next) {
        setIsArMode(false);
        if (!compareOutfitB) {
          const otherHistory = outfitHistory.find(
            (h) => h.id !== activeHistoryId
          );
          if (otherHistory) {
            setCompareOutfitB(cloneOutfitConfig(otherHistory.outfit));
            setActiveHistoryIdB(otherHistory.id);
          } else if (outfitHistory.length > 0) {
            setCompareOutfitB(cloneOutfitConfig(outfitHistory[0].outfit));
            setActiveHistoryIdB(outfitHistory[0].id);
          } else {
            const genderPresets = SUGGESTED_OUTFIT_PRESETS.filter(
              (p) =>
                p.genderHint ===
                (body.genderProfile === 'male' ? 'male' : 'female')
            );
            const fallbackPreset = genderPresets[1] || genderPresets[0];
            if (fallbackPreset) {
              setCompareOutfitB({
                ...fallbackPreset.outfit,
                selectedSize: body.genderProfile === 'male' ? 'L' : 'M',
                hideAllGarments: false,
              });
              setActiveHistoryIdB(null);
            }
          }
        }
      }
      return next;
    });
  }, [
    compareOutfitB,
    outfitHistory,
    activeHistoryId,
    body.genderProfile,
  ]);

  const handleDeleteHistoryEntry = useCallback((id: string) => {
    setOutfitHistory((prev) => prev.filter((item) => item.id !== id));
    setActiveHistoryId((prev) => (prev === id ? null : prev));
    setActiveHistoryIdB((prev) => (prev === id ? null : prev));
  }, []);

  const handleClearHistory = useCallback(() => {
    setOutfitHistory([]);
    setActiveHistoryId(null);
    setActiveHistoryIdB(null);
    try {
      sessionStorage.removeItem(TEMP_HISTORY_STORAGE_KEY);
    } catch {
      // Ignore storage error
    }
  }, []);

  const handleQuickFlipAB = useCallback(() => {
    if (outfitHistory.length === 0) return;
    if (outfitHistory.length === 1) {
      handleApplyHistoryEntry(outfitHistory[0]);
      return;
    }
    const idx = outfitHistory.findIndex((h) => h.id === activeHistoryId);
    const nextEntry = idx === 0 ? outfitHistory[1] : outfitHistory[0];
    handleApplyHistoryEntry(nextEntry);
  }, [outfitHistory, activeHistoryId, handleApplyHistoryEntry]);

  const handleResetAll = useCallback(() => {
    setBody(DEFAULT_BODY_MEASUREMENTS);
    setOutfit(DEFAULT_OUTFIT);
    setCompareOutfitB(null);
    setIsSplitCompareMode(false);
    setPosePreset('stand_still');
    setLastAiPoseResult(null);
    setWeatherEffect(DEFAULT_WEATHER_EFFECT);
    setJointRotations({ ...ZERO_JOINT_ROTATIONS });
    setCameraPreset('full_front');
    setCameraResetTrigger((c) => c + 1);
    setLightingPreset('daylight_studio');
    setShowMeasurementTape(false);
    setIsArMode(false);
    setActiveHistoryId(null);
    setActiveHistoryIdB(null);
  }, []);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLSelectElement
      ) {
        return;
      }
      if (e.key.toLowerCase() === 'h') {
        setIsDockCollapsed((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, []);

  return (
    <div className="flex flex-col w-screen h-screen overflow-hidden bg-[#FAF9F6] text-[#0F172A]">
      <TopStudioBar
        activeTab={activeTab}
        onSelectTab={(tab) => {
          setActiveTab(tab);
          setIsDockCollapsed(false);
        }}
        showMeasurementTape={showMeasurementTape}
        onToggleMeasurementTape={() => setShowMeasurementTape((prev) => !prev)}
        isSplitCompareMode={isSplitCompareMode}
        onToggleSplitCompareMode={handleToggleSplitCompareMode}
        isArMode={isArMode}
        onToggleArMode={() => {
          setIsArMode((prev) => {
            const next = !prev;
            if (next) {
              setIsDockCollapsed(true);
              setIsSplitCompareMode(false);
            }
            return next;
          });
        }}
        onResetAll={handleResetAll}
        onTriggerVideoWalkthrough={() =>
          setVideoWalkthroughTrigger((c) => c + 1)
        }
        onTriggerExportGlb={() => setExportGlbTrigger((c) => c + 1)}
        onTriggerExportUsdz={() => setExportUsdzTrigger((c) => c + 1)}
        outfitHistoryCount={outfitHistory.length}
        onToggleHistoryModal={() => setIsHistoryModalOpen((prev) => !prev)}
      />

      <main className="relative flex-1 w-full h-full overflow-hidden">
        {/* Top-Left Interactive Model Info Popup Card — only shown when Bottom Dock is collapsed and not in AR or Split-Screen mode */}
        {isDockCollapsed && !isArMode && !isSplitCompareMode && (
        <div className="absolute top-3 left-3 z-10 hidden md:flex flex-col gap-2 w-[295px] max-h-[calc(100%-64px)] overflow-y-auto bg-white/95 border border-slate-200 rounded-xl p-3 shadow-sm">
          {/* Gender Switch + Zoom Toggle */}
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-1 p-0.5 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() =>
                  handleUpdateHeightWeight(body.heightCm, body.weightKg, 'female')
                }
                className={`px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors cursor-pointer ${
                  body.genderProfile === 'female'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Mẫu Nữ (3 Vòng)
              </button>
              <button
                type="button"
                onClick={() =>
                  handleUpdateHeightWeight(body.heightCm, body.weightKg, 'male')
                }
                className={`px-2.5 py-1 text-[11px] font-medium rounded-md transition-colors cursor-pointer ${
                  body.genderProfile === 'male'
                    ? 'bg-slate-900 text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Mẫu Nam (BMI)
              </button>
            </div>
            <button
              type="button"
              onClick={() =>
                setCameraPreset((prev) =>
                  prev === 'upper_detail' ? 'full_front' : 'upper_detail'
                )
              }
              className="px-2 py-1 text-[11px] font-medium rounded-md border border-slate-200 bg-white text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer whitespace-nowrap"
            >
              {cameraPreset === 'upper_detail'
                ? 'Góc Toàn Thân'
                : 'Zoom Cận Mặt'}
            </button>
          </div>

          {/* Direct Height (100-300cm) & Weight (20-500kg) Range Sliders in Popup */}
          <div className="grid grid-cols-2 gap-2">
            <div className="p-2 bg-slate-50 border border-slate-200/80 rounded-lg">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-slate-600 font-medium">Chiều cao</span>
                <span className="font-mono font-bold text-slate-900">
                  {body.heightCm} cm
                </span>
              </div>
              <input
                type="range"
                min={100}
                max={300}
                step={1}
                value={body.heightCm}
                onChange={(e) =>
                  handleUpdateHeightWeight(
                    Number(e.target.value),
                    body.weightKg
                  )
                }
                className="w-full studio-slider"
              />
            </div>

            <div className="p-2 bg-slate-50 border border-slate-200/80 rounded-lg">
              <div className="flex items-center justify-between text-[11px] mb-1">
                <span className="text-slate-600 font-medium">Cân nặng</span>
                <span className="font-mono font-bold text-slate-900">
                  {body.weightKg} kg
                </span>
              </div>
              <input
                type="range"
                min={20}
                max={500}
                step={1}
                value={body.weightKg}
                onChange={(e) =>
                  handleUpdateHeightWeight(
                    body.heightCm,
                    Number(e.target.value)
                  )
                }
                className="w-full studio-slider"
              />
            </div>
          </div>

          {/* Hairstyle Dropdown + Quick Buttons & Color Swatches in Popup (Strictly Separated by Gender) */}
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label
                htmlFor="popup-hairstyle-select"
                className="block text-[11px] font-semibold text-slate-800"
              >
                {body.genderProfile === 'male'
                  ? 'Kiểu Tóc Nam Riêng Biệt (11 Kiểu)'
                  : 'Kiểu Tóc Nữ Riêng Biệt (13 Kiểu)'}
              </label>
              <div className="flex items-center gap-1">
                {HAIR_COLOR_SWATCHES.slice(0, 6).map((hc) => (
                  <button
                    key={hc.hex}
                    type="button"
                    title={hc.name}
                    onClick={() => handleUpdateBodyField('hairColorHex', hc.hex)}
                    className={`w-3.5 h-3.5 rounded-full border transition-transform cursor-pointer ${
                      body.hairColorHex.toLowerCase() === hc.hex.toLowerCase()
                        ? 'ring-2 ring-slate-900 ring-offset-1 scale-110 border-slate-400'
                        : 'border-slate-300 hover:scale-105'
                    }`}
                    style={{ backgroundColor: hc.hex }}
                  />
                ))}
                <label
                  title="Tự chọn màu tóc bất kỳ"
                  className="relative w-4 h-4 rounded-full border border-indigo-400 overflow-hidden cursor-pointer shadow-xs"
                  style={{ backgroundColor: body.hairColorHex }}
                >
                  <input
                    type="color"
                    value={body.hairColorHex}
                    onChange={(e) => handleUpdateBodyField('hairColorHex', e.target.value)}
                    className="opacity-0 absolute inset-0 w-full h-full cursor-pointer"
                  />
                </label>
              </div>
            </div>

            <select
              id="popup-hairstyle-select"
              value={body.hairstyleId}
              onChange={(e) =>
                handleUpdateBodyField(
                  'hairstyleId',
                  e.target.value as HairstyleId
                )
              }
              className="w-full px-2.5 py-1.5 text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg text-slate-900 focus:outline-none focus:border-slate-900 cursor-pointer"
            >
              {HAIRSTYLE_OPTIONS.filter(
                (h) =>
                  h.genderHint ===
                    (body.genderProfile === 'male' ? 'male' : 'female') ||
                  h.genderHint === 'unisex'
              ).map((h) => (
                <option key={h.id} value={h.id}>
                  {h.name}
                </option>
              ))}
            </select>

            <div className="grid grid-cols-4 gap-1">
              {(body.genderProfile === 'male'
                ? ([
                    { id: 'mushroom_cut', label: 'Đầu Nấm' },
                    { id: 'middle_part_curtain', label: 'Rẽ Ngôi 5/5' },
                    { id: 'comma_hair_korean', label: 'Comma Hair' },
                    { id: 'slicked_side_part', label: 'Rẽ Ngôi 7/3' },
                    { id: 'undercut_quiff', label: 'Undercut' },
                    { id: 'two_block_layer', label: 'Two-Block' },
                    { id: 'wolf_mullet_male', label: 'Mullet Nam' },
                    { id: 'male_curly_quiff', label: 'Xoăn Nam' },
                  ] as { id: HairstyleId; label: string }[])
                : ([
                    { id: 'long_wavy', label: 'Dài Sóng' },
                    { id: 'long_straight', label: 'Dài Thẳng' },
                    { id: 'curly_voluminous', label: 'Xoăn Sóng' },
                    { id: 'korean_hime_layer', label: 'Tóc Hime' },
                    { id: 'butterfly_wolf_cut', label: 'Layer Bướm' },
                    { id: 'clavicle_lob', label: 'Ngang Vai' },
                    { id: 'high_ponytail', label: 'Đuôi Ngựa' },
                    { id: 'low_chignon', label: 'Búi Thấp' },
                  ] as { id: HairstyleId; label: string }[])
              ).map((hk) => (
                <button
                  key={hk.id}
                  type="button"
                  onClick={() => handleUpdateBodyField('hairstyleId', hk.id)}
                  className={`px-1.5 py-1 text-[10px] font-medium rounded border truncate transition-colors cursor-pointer ${
                    body.hairstyleId === hk.id
                      ? 'bg-slate-900 text-white border-slate-900'
                      : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  {hk.label}
                </button>
              ))}
            </div>
          </div>

          {/* Conditional Gender Body Shape + Female 3D Makeup Studio Section */}
          {body.genderProfile !== 'male' ? (
            <>
              <div className="p-2 bg-rose-50/70 border border-rose-200/80 rounded-lg space-y-1.5">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-semibold text-rose-950">
                    Trang Điểm Nữ &amp; Lens Mắt 3D
                  </span>
                  <div className="flex items-center gap-1">
                    {EYE_LENS_SWATCHES.map((lens) => (
                      <button
                        key={lens.hex}
                        type="button"
                        title={`Màu mắt: ${lens.name}`}
                        onClick={() =>
                          handleUpdateBodyField('eyeColorHex', lens.hex)
                        }
                        className={`w-3.5 h-3.5 rounded-full border transition-transform cursor-pointer ${
                          body.eyeColorHex.toLowerCase() ===
                          lens.hex.toLowerCase()
                            ? 'ring-2 ring-rose-700 ring-offset-1 scale-110 border-white'
                            : 'border-slate-300 hover:scale-105'
                        }`}
                        style={{ backgroundColor: lens.hex }}
                      />
                    ))}
                  </div>
                </div>

                {/* 6 Makeup Style Presets */}
                <div className="grid grid-cols-3 gap-1">
                  {MAKEUP_PRESETS.map((mp) => (
                    <button
                      key={mp.id}
                      type="button"
                      onClick={() =>
                        handleUpdateBodyField('makeup', { ...mp.config })
                      }
                      className={`px-1.5 py-1 text-[10px] font-medium rounded border truncate transition-colors cursor-pointer ${
                        body.makeup.presetId === mp.id
                          ? 'bg-rose-700 text-white border-rose-700'
                          : 'bg-white text-slate-700 border-rose-200/80 hover:bg-rose-50'
                      }`}
                    >
                      {mp.name}
                    </button>
                  ))}
                </div>

                {/* Lipstick Color Swatches + Lip Intensity Slider */}
                <div className="flex items-center justify-between gap-2 pt-0.5">
                  <div className="flex items-center gap-1">
                    <span className="text-[10px] font-medium text-rose-900 mr-0.5">
                      Son:
                    </span>
                    {LIPSTICK_SWATCHES.map((lip) => (
                      <button
                        key={lip.hex}
                        type="button"
                        title={lip.name}
                        onClick={() =>
                          handleUpdateBodyField('makeup', {
                            ...body.makeup,
                            lipColorHex: lip.hex,
                            lipIntensity: Math.max(
                              0.68,
                              body.makeup.lipIntensity
                            ),
                          })
                        }
                        className={`w-3.5 h-3.5 rounded-full border transition-transform cursor-pointer ${
                          body.makeup.lipColorHex.toLowerCase() ===
                          lip.hex.toLowerCase()
                            ? 'ring-2 ring-slate-900 ring-offset-1 scale-110 border-white'
                            : 'border-rose-200 hover:scale-105'
                        }`}
                        style={{ backgroundColor: lip.hex }}
                      />
                    ))}
                  </div>
                  <button
                    type="button"
                    onClick={() =>
                      handleUpdateBodyField('makeup', {
                        ...body.makeup,
                        lipGloss: body.makeup.lipGloss > 0.5 ? 0.15 : 0.85,
                      })
                    }
                    className="px-1.5 py-0.5 text-[10px] font-medium rounded bg-white border border-rose-200 text-rose-800 hover:bg-rose-100 cursor-pointer shrink-0"
                  >
                    {body.makeup.lipGloss > 0.5 ? 'Son Bóng' : 'Son Lì'}
                  </button>
                </div>
              </div>

              <div className="p-2 bg-slate-50 border border-slate-200/90 rounded-lg space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="font-semibold text-slate-800">
                    Số đo 3 Vòng Nữ:
                  </span>
                  <span className="font-bold text-blue-700">
                    {fitAnalysis.bodyShapeName}
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  <div>
                    <div className="flex justify-between text-[10px] text-slate-600">
                      <span>Ngực</span>
                      <span className="font-mono font-semibold">
                        {body.chestCm}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={62}
                      max={160}
                      value={body.chestCm}
                      onChange={(e) =>
                        handleUpdateBodyField('chestCm', Number(e.target.value))
                      }
                      className="w-full studio-slider"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px] text-slate-600">
                      <span>Eo</span>
                      <span className="font-mono font-semibold">
                        {body.waistCm}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={46}
                      max={150}
                      value={body.waistCm}
                      onChange={(e) =>
                        handleUpdateBodyField('waistCm', Number(e.target.value))
                      }
                      className="w-full studio-slider"
                    />
                  </div>
                  <div>
                    <div className="flex justify-between text-[10px] text-slate-600">
                      <span>Hông</span>
                      <span className="font-mono font-semibold">
                        {body.hipCm}
                      </span>
                    </div>
                    <input
                      type="range"
                      min={68}
                      max={165}
                      value={body.hipCm}
                      onChange={(e) =>
                        handleUpdateBodyField('hipCm', Number(e.target.value))
                      }
                      className="w-full studio-slider"
                    />
                  </div>
                </div>
              </div>
            </>
          ) : (
            <div className="p-2 bg-slate-50 border border-slate-200/90 rounded-lg">
              <div className="flex items-center justify-between text-[11px] mb-0.5">
                <span className="font-semibold text-slate-800">
                  Chỉ số BMI Nam: <strong className="font-mono">{fitAnalysis.bmi}</strong>
                </span>
                <span className="font-bold text-blue-700">
                  Size {fitAnalysis.recommendedSize}
                </span>
              </div>
              <div className="text-[11px] font-semibold text-slate-900">
                {fitAnalysis.bodyShapeName}
              </div>
            </div>
          )}
        </div>
        )}

        {/* Top-Right Visual Outfit Score + Suggested Outfits + AI Upload Card — only shown when Bottom Dock is collapsed and not in AR or Split-Screen mode */}
        {isDockCollapsed && !isArMode && !isSplitCompareMode && (
        <div className="absolute top-3 right-3 z-10 hidden lg:flex flex-col gap-2 w-[285px] max-h-[calc(100%-64px)] overflow-y-auto bg-white/95 border border-slate-200 rounded-xl p-3 shadow-sm">
          {/* Visual Outfit Score Header */}
          <div className="flex items-center justify-between gap-2 pb-2 border-b border-slate-100">
            <div className="min-w-0">
              <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-700">
                <Award className="w-3.5 h-3.5 shrink-0" />
                <span>Chấm Điểm Outfit Trực Quan</span>
              </div>
              <div className="text-xs font-bold text-slate-900 truncate">
                {score.verdictTitle}
              </div>
            </div>
            <div className="px-2.5 py-1 rounded-lg bg-slate-900 text-white text-right shrink-0 font-mono">
              <div className="text-sm font-bold leading-none">
                {score.totalScore}/100
              </div>
              <div className="text-[10px] text-amber-300 font-semibold mt-0.5">
                Hạng {score.grade}
              </div>
            </div>
          </div>

          {/* Compact Score Bars */}
          <div className="grid grid-cols-2 gap-x-3 gap-y-1 text-[10px]">
            <div>
              <div className="flex justify-between text-slate-600">
                <span>Độ vừa vặn</span>
                <span className="font-mono font-semibold">{score.fitScore}%</span>
              </div>
              <div className="w-full h-1 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-emerald-600"
                  style={{ width: `${score.fitScore}%` }}
                />
              </div>
            </div>
            <div>
              <div className="flex justify-between text-slate-600">
                <span>Hài hòa màu</span>
                <span className="font-mono font-semibold">
                  {score.colorHarmonyScore}%
                </span>
              </div>
              <div className="w-full h-1 bg-slate-200 rounded-full overflow-hidden">
                <div
                  className="h-full bg-blue-600"
                  style={{ width: `${score.colorHarmonyScore}%` }}
                />
              </div>
            </div>
          </div>

          {/* Suggested Lookbook Outfits (Filtered by Gender) */}
          <div>
            <div className="text-[11px] font-semibold text-slate-700 mb-1">
              {body.genderProfile === 'male'
                ? 'Trang Phục Nam Gợi Ý (Chạm để thay)'
                : 'Trang Phục Nữ Gợi Ý (Chạm để thay)'}
            </div>
            <div className="grid grid-cols-2 gap-1">
              {SUGGESTED_OUTFIT_PRESETS.filter(
                (preset) =>
                  preset.genderHint ===
                  (body.genderProfile === 'male' ? 'male' : 'female')
              ).map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() =>
                    setOutfit({
                      ...preset.outfit,
                      selectedSize: body.genderProfile === 'male' ? 'L' : 'S',
                      hideAllGarments: false,
                    })
                  }
                  className="px-2 py-1 text-[11px] font-medium bg-slate-100 hover:bg-slate-900 hover:text-white text-slate-700 rounded transition-colors cursor-pointer truncate text-left"
                >
                  {preset.name}
                </button>
              ))}
            </div>
          </div>

          {/* Temporary Outfit History & Quick Comparison Section */}
          <div className="pt-2 border-t border-slate-100 space-y-1.5">
            <div className="flex items-center justify-between gap-1">
              <div className="flex items-center gap-1 text-[11px] font-semibold text-indigo-900">
                <History className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
                <span>Lịch sử phối đồ ({outfitHistory.length})</span>
              </div>
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={handleToggleSplitCompareMode}
                  title="So sánh song song 2 cấu hình trên 2 nửa màn hình"
                  className="flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-semibold bg-indigo-50 hover:bg-indigo-600 text-indigo-900 hover:text-white border border-indigo-200 rounded transition-colors cursor-pointer"
                >
                  <Columns2 className="w-2.5 h-2.5" />
                  <span>Đôi A|B</span>
                </button>
                {outfitHistory.length >= 2 && (
                  <button
                    type="button"
                    onClick={handleQuickFlipAB}
                    title="Đảo nhanh giữa 2 bộ phối gần nhất"
                    className="flex items-center gap-0.5 px-1.5 py-0.5 text-[10px] font-semibold bg-amber-100 hover:bg-amber-500 text-amber-900 hover:text-white rounded transition-colors cursor-pointer"
                  >
                    <ArrowLeftRight className="w-2.5 h-2.5" />
                    <span>A↔B</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={handleSaveCurrentOutfit}
                  className="flex items-center gap-1 px-2 py-0.5 text-[10px] font-semibold bg-indigo-600 hover:bg-indigo-700 text-white rounded transition-colors cursor-pointer"
                >
                  <BookmarkPlus className="w-3 h-3" />
                  <span>Lưu bộ này</span>
                </button>
              </div>
            </div>

            {outfitHistory.length === 0 ? (
              <div className="text-[10px] text-slate-500 bg-slate-50 border border-dashed border-slate-200 rounded-lg px-2 py-1.5 text-center">
                Nhấn <strong>&ldquo;Lưu bộ này&rdquo;</strong> để lưu tạm các lựa chọn và so sánh song song trên người mẫu 3D.
              </div>
            ) : (
              <div className="space-y-1 max-h-[128px] overflow-y-auto pr-0.5">
                {outfitHistory.map((entry, idx) => {
                  const isCurrentActive = activeHistoryId === entry.id;
                  const diff = entry.score.totalScore - score.totalScore;
                  return (
                    <div
                      key={entry.id}
                      onClick={() => handleApplyHistoryEntry(entry)}
                      className={`flex items-center justify-between gap-1.5 px-2 py-1.5 rounded-lg border text-left transition-colors cursor-pointer ${
                        isCurrentActive
                          ? 'bg-slate-900 text-white border-slate-900'
                          : 'bg-slate-50 hover:bg-indigo-50/70 text-slate-800 border-slate-200/90'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span
                          className={`text-[10px] font-mono font-bold px-1 rounded shrink-0 ${
                            isCurrentActive
                              ? 'bg-indigo-500 text-white'
                              : 'bg-indigo-100 text-indigo-800'
                          }`}
                        >
                          #{outfitHistory.length - idx}
                        </span>
                        <div className="flex items-center gap-0.5 shrink-0">
                          {entry.outfit.top.styleId !== 'none' && (
                            <span
                              className="w-2.5 h-2.5 rounded-full border border-slate-300"
                              style={{
                                backgroundColor: entry.outfit.top.colorHex,
                              }}
                            />
                          )}
                          {entry.outfit.outerwear.styleId !== 'none' && (
                            <span
                              className="w-2.5 h-2.5 rounded-full border border-slate-300"
                              style={{
                                backgroundColor:
                                  entry.outfit.outerwear.colorHex,
                              }}
                            />
                          )}
                          {entry.outfit.bottom.styleId !== 'none' && (
                            <span
                              className="w-2.5 h-2.5 rounded-full border border-slate-300"
                              style={{
                                backgroundColor: entry.outfit.bottom.colorHex,
                              }}
                            />
                          )}
                        </div>
                        <span className="text-[11px] font-medium truncate">
                          {entry.label}
                        </span>
                      </div>

                      <div className="flex items-center gap-1 shrink-0 font-mono text-[10px]">
                        <button
                          type="button"
                          title="So sánh song song bộ này ở Khung B"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleSelectCompareHistoryB(entry);
                          }}
                          className={`px-1 py-0.2 text-[9px] font-bold rounded cursor-pointer ${
                            isCurrentActive
                              ? 'bg-white/15 hover:bg-indigo-500 text-white'
                              : 'bg-indigo-100 hover:bg-indigo-600 text-indigo-800 hover:text-white'
                          }`}
                        >
                          So B
                        </button>
                        <span className="font-bold">
                          {entry.score.totalScore}đ
                        </span>
                        {!isCurrentActive && diff !== 0 && (
                          <span
                            className={`px-1 rounded font-bold ${
                              diff > 0
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {diff > 0 ? `+${diff}` : diff}
                          </span>
                        )}
                        <button
                          type="button"
                          title="Xóa"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeleteHistoryEntry(entry.id);
                          }}
                          className={`p-0.5 rounded cursor-pointer ${
                            isCurrentActive
                              ? 'text-slate-300 hover:text-white'
                              : 'text-slate-400 hover:text-red-600'
                          }`}
                        >
                          <X className="w-2.5 h-2.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Quick Pose AI Generator Box in Left Studio Card */}
          <div className="pt-2 border-t border-slate-100 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-[11px] font-bold text-slate-900 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-500" />
                <span>Pose AI Generator (Tư thế tự nhiên)</span>
              </span>
              <button
                type="button"
                onClick={() => {
                  setActiveTab('pose');
                  setIsDockCollapsed(false);
                }}
                className="text-[10px] font-semibold text-indigo-600 hover:text-indigo-700 cursor-pointer"
              >
                Mở 17 khớp
              </button>
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!quickPosePrompt.trim() || isGeneratingPose) return;
                handleGenerateAiPose(quickPosePrompt.trim());
              }}
              className="flex items-center gap-1"
            >
              <input
                type="text"
                value={quickPosePrompt}
                onChange={(e) => setQuickPosePrompt(e.target.value)}
                placeholder="VD: đang ngồi bắt chéo chân, chống nạnh..."
                className="flex-1 min-w-0 px-2 py-1 text-[11px] bg-slate-50 border border-slate-200 rounded-md text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-indigo-600"
              />
              <button
                type="submit"
                disabled={isGeneratingPose || !quickPosePrompt.trim()}
                className="flex items-center gap-1 px-2 py-1 rounded-md bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white text-[10px] font-bold cursor-pointer shrink-0"
              >
                {isGeneratingPose ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <Send className="w-3 h-3" />
                )}
                <span>Tạo dáng</span>
              </button>
            </form>

            <div className="flex flex-wrap gap-1">
              {POSE_AI_SUGGESTION_PROMPTS.slice(0, 4).map((chip) => (
                <button
                  key={chip.label}
                  type="button"
                  disabled={isGeneratingPose}
                  onClick={() => {
                    setQuickPosePrompt(chip.prompt);
                    handleGenerateAiPose(chip.prompt);
                  }}
                  className="px-1.5 py-0.5 text-[9px] font-medium rounded bg-slate-100 hover:bg-indigo-600 hover:text-white text-slate-700 transition-colors cursor-pointer"
                >
                  {chip.label}
                </button>
              ))}
            </div>
          </div>

          {/* Quick Upload Garment Image Button + Upload-Matched Suggestions + Quick AI Color Palettes */}
          <div className="pt-1.5 border-t border-slate-100 space-y-2">
            <div className="flex items-center justify-between gap-2">
              <input
                ref={quickUploadRef}
                type="file"
                accept="image/*"
                onChange={handleQuickGarmentUpload}
                className="hidden"
              />
              <span className="text-[10px] text-slate-600 font-medium truncate">
                {outfit.outerwear.transformedSummary ||
                outfit.top.transformedSummary ||
                outfit.bottom.transformedSummary
                  ? `AI 3D: ${
                      outfit.outerwear.transformedSummary ||
                      outfit.top.transformedSummary ||
                      outfit.bottom.transformedSummary
                    }`
                  : 'Tải ảnh quần áo để AI dựng 3D & gợi ý phối đồ'}
              </span>
              <button
                type="button"
                disabled={isQuickUploading}
                onClick={() => quickUploadRef.current?.click()}
                className="flex items-center gap-1 px-2.5 py-1 bg-blue-600 hover:bg-blue-700 text-white text-[11px] font-medium rounded-md transition-colors cursor-pointer shrink-0"
              >
                <Upload className="w-3 h-3" />
                <span>{isQuickUploading ? 'Đang biến hoá...' : 'Upload Đồ'}</span>
              </button>
            </div>

            {/* Quick Upload-Matched Outfit Recommendations */}
            <div className="p-2 rounded-lg bg-blue-50/70 border border-blue-200/80 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-blue-950 flex items-center gap-1">
                  <Shirt className="w-3 h-3 text-blue-600" />
                  <span>
                    {hasUploadedPiece
                      ? 'Gợi ý phối hợp với đồ bạn vừa Upload:'
                      : 'Gợi ý phối đồ ăn ý với món đang mặc:'}
                  </span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('wardrobe');
                    setIsDockCollapsed(false);
                  }}
                  className="text-[9px] font-semibold text-blue-700 hover:underline cursor-pointer"
                >
                  Chi tiết
                </button>
              </div>
              <div className="grid grid-cols-2 gap-1">
                {quickUploadRecommendations.slice(0, 2).map((rec) => (
                  <button
                    key={rec.id}
                    type="button"
                    onClick={() => {
                      setOutfit(rec.outfit);
                      setActiveHistoryId(null);
                    }}
                    className="p-1.5 rounded bg-white hover:bg-blue-600 hover:text-white text-slate-800 border border-blue-200/80 text-left transition-colors cursor-pointer"
                  >
                    <div className="text-[10px] font-bold truncate">
                      {rec.title}
                    </div>
                    <div className="text-[9px] opacity-80 truncate">
                      {rec.styleTag}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Color Palette Generator Strip */}
            <div className="p-2 rounded-lg bg-violet-50/70 border border-violet-200/80 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-bold text-violet-950 flex items-center gap-1">
                  <Palette className="w-3 h-3 text-violet-600" />
                  <span>Color Palette AI (Phối màu chuyên nghiệp):</span>
                </span>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('wardrobe');
                    setIsDockCollapsed(false);
                  }}
                  className="text-[9px] font-semibold text-violet-700 hover:underline cursor-pointer"
                >
                  Mở 5 hệ màu
                </button>
              </div>
              <div className="grid grid-cols-3 gap-1">
                {quickColorPalettes.palettes.slice(0, 3).map((pal) => (
                  <button
                    key={pal.id}
                    type="button"
                    title={`${pal.paletteName} — ${pal.theoryExplanation}`}
                    onClick={() => {
                      setOutfit((prev) => ({
                        ...prev,
                        hideAllGarments: false,
                        top: { ...prev.top, colorHex: pal.topColorHex },
                        outerwear: {
                          ...prev.outerwear,
                          colorHex: pal.outerwearColorHex,
                        },
                        bottom: {
                          ...prev.bottom,
                          colorHex: pal.bottomColorHex,
                        },
                        footwear: {
                          ...prev.footwear,
                          colorHex: pal.footwearColorHex,
                        },
                      }));
                      setActiveHistoryId(null);
                    }}
                    className="p-1 rounded bg-white hover:bg-violet-600 hover:text-white text-slate-800 border border-violet-200 text-left transition-colors cursor-pointer"
                  >
                    <div className="text-[9px] font-bold truncate">
                      {pal.schemeLabel}
                    </div>
                    <div className="flex items-center gap-0.5 mt-0.5">
                      {pal.swatches.slice(0, 4).map((sw, i) => (
                        <span
                          key={i}
                          className="w-2.5 h-2.5 rounded-full border border-black/20"
                          style={{ backgroundColor: sw.hex }}
                        />
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
        )}

        {/* Mobile Quick Action AI Bar (Tự nhập miêu tả hành động trên điện thoại) */}
        {!isArMode && (
          <div className="sm:hidden absolute top-2 left-2 right-14 z-10 pointer-events-auto">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                if (!quickPosePrompt.trim() || isGeneratingPose) return;
                handleGenerateAiPose(quickPosePrompt.trim());
              }}
              className="flex items-center gap-1.5 bg-white/95 backdrop-blur-md border border-slate-200/90 rounded-xl px-2.5 py-1.5 shadow-md"
            >
              <Sparkles className="w-3.5 h-3.5 text-indigo-600 shrink-0" />
              <input
                type="text"
                value={quickPosePrompt}
                onChange={(e) => setQuickPosePrompt(e.target.value)}
                placeholder="Nhập hành động (VD: khoanh tay, thả tim, ngồi...)"
                className="flex-1 min-w-0 text-[11px] bg-transparent text-slate-900 placeholder:text-slate-400 focus:outline-none"
              />
              <button
                type="submit"
                disabled={isGeneratingPose || !quickPosePrompt.trim()}
                className="flex items-center gap-1 px-2 py-1 rounded-lg bg-indigo-600 text-white text-[10px] font-bold disabled:opacity-50 shrink-0"
              >
                {isGeneratingPose ? (
                  <Loader2 className="w-3 h-3 animate-spin" />
                ) : (
                  <Send className="w-3 h-3" />
                )}
                <span>Tạo dáng</span>
              </button>
            </form>
          </div>
        )}

        {/* Full Outfit History Review & Delete Modal */}
        {isHistoryModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-xs p-4">
            <div className="w-full max-w-2xl bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden flex flex-col max-h-[82vh]">
              <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <div className="p-1.5 rounded-lg bg-indigo-500/20 border border-indigo-400/40 text-indigo-300">
                    <History className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold">
                      Lịch Sử Trang Phục Đã Phối ({outfitHistory.length}/12)
                    </h3>
                    <p className="text-[11px] text-slate-300">
                      Xem lại các bộ trang phục đã lưu, mặc thử lại hoặc xoá bớt những bộ không thích
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleSaveCurrentOutfit}
                    className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-semibold cursor-pointer"
                  >
                    <BookmarkPlus className="w-3.5 h-3.5" />
                    <span>Lưu bộ đang mặc</span>
                  </button>
                  {outfitHistory.length > 0 && (
                    <button
                      type="button"
                      onClick={handleClearHistory}
                      className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-rose-600/20 hover:bg-rose-600 text-rose-200 hover:text-white border border-rose-500/30 text-xs font-semibold cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      <span>Xoá tất cả</span>
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => setIsHistoryModalOpen(false)}
                    className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="p-4 overflow-y-auto space-y-2.5">
                {outfitHistory.length === 0 ? (
                  <div className="py-10 text-center space-y-2 bg-slate-50 rounded-xl border border-dashed border-slate-300">
                    <History className="w-8 h-8 text-slate-400 mx-auto" />
                    <div className="text-sm font-bold text-slate-800">
                      Chưa có bộ trang phục nào trong lịch sử
                    </div>
                    <p className="text-xs text-slate-500 max-w-md mx-auto">
                      Hãy nhấn nút <strong>&ldquo;Lưu bộ đang mặc&rdquo;</strong> ở trên để lưu lại cấu hình hiện tại vào danh sách.
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    {outfitHistory.map((entry, idx) => {
                      const isCurrentActive = activeHistoryId === entry.id;
                      return (
                        <div
                          key={entry.id}
                          className={`p-3 rounded-xl border flex flex-col justify-between gap-2 transition-all ${
                            isCurrentActive
                              ? 'bg-slate-900 text-white border-slate-900'
                              : 'bg-slate-50 text-slate-800 border-slate-200 hover:border-indigo-400'
                          }`}
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="min-w-0">
                              <div className="flex items-center gap-1.5">
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-indigo-600 text-white">
                                  Bộ #{outfitHistory.length - idx}
                                </span>
                                <span
                                  className={`text-[10px] font-mono ${
                                    isCurrentActive
                                      ? 'text-slate-300'
                                      : 'text-slate-500'
                                  }`}
                                >
                                  Lúc {entry.timestamp} · Size{' '}
                                  {entry.outfit.selectedSize}
                                </span>
                              </div>
                              <div className="text-xs font-bold mt-1 truncate">
                                {entry.label}
                              </div>
                              <div
                                className={`text-[11px] mt-0.5 ${
                                  isCurrentActive
                                    ? 'text-amber-300'
                                    : 'text-indigo-700'
                                } font-semibold`}
                              >
                                Điểm AI: {entry.score.totalScore}/100 (Hạng{' '}
                                {entry.score.grade})
                              </div>
                            </div>

                            <button
                              type="button"
                              onClick={() => handleDeleteHistoryEntry(entry.id)}
                              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-rose-100 hover:bg-rose-600 text-rose-700 hover:text-white text-[11px] font-semibold transition-colors cursor-pointer shrink-0"
                              title="Xoá bộ trang phục không thích này"
                            >
                              <Trash2 className="w-3 h-3" />
                              <span>Xoá bộ này</span>
                            </button>
                          </div>

                          <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200/30">
                            <div className="flex items-center gap-1.5">
                              {entry.outfit.top.styleId !== 'none' && (
                                <span
                                  title="Màu Áo trong"
                                  className="w-4 h-4 rounded-full border border-slate-300"
                                  style={{
                                    backgroundColor:
                                      entry.outfit.top.colorHex,
                                  }}
                                />
                              )}
                              {entry.outfit.outerwear.styleId !== 'none' && (
                                <span
                                  title="Màu Áo khoác"
                                  className="w-4 h-4 rounded-full border border-slate-300"
                                  style={{
                                    backgroundColor:
                                      entry.outfit.outerwear.colorHex,
                                  }}
                                />
                              )}
                              {entry.outfit.bottom.styleId !== 'none' && (
                                <span
                                  title="Màu Quần/Váy"
                                  className="w-4 h-4 rounded-full border border-slate-300"
                                  style={{
                                    backgroundColor:
                                      entry.outfit.bottom.colorHex,
                                  }}
                                />
                              )}
                              {entry.outfit.footwear.styleId !== 'none' && (
                                <span
                                  title="Màu Giày"
                                  className="w-4 h-4 rounded-full border border-slate-300"
                                  style={{
                                    backgroundColor:
                                      entry.outfit.footwear.colorHex,
                                  }}
                                />
                              )}
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                type="button"
                                onClick={() => {
                                  handleSelectCompareHistoryB(entry);
                                  setIsHistoryModalOpen(false);
                                }}
                                className="px-2 py-1 rounded-md text-[11px] font-semibold bg-indigo-100 hover:bg-indigo-600 text-indigo-900 hover:text-white transition-colors cursor-pointer"
                              >
                                So sánh A|B
                              </button>
                              <button
                                type="button"
                                onClick={() => {
                                  handleApplyHistoryEntry(entry);
                                  setIsHistoryModalOpen(false);
                                }}
                                className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors cursor-pointer"
                              >
                                {isCurrentActive ? 'Đang mặc' : 'Mặc lại bộ này'}
                              </button>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        <MannequinViewport
          body={body}
          outfit={outfit}
          posePreset={posePreset}
          jointRotations={jointRotations}
          selectedJoint={selectedJoint}
          onSelectJoint={handleSelectJointFrom3D}
          cameraPreset={cameraPreset}
          lightingPreset={lightingPreset}
          showMeasurementTape={showMeasurementTape}
          resetTrigger={cameraResetTrigger}
          onResetToTPose={handleStandStillPose}
          isArMode={isArMode}
          onToggleArMode={() => {
            setIsArMode((prev) => {
              const next = !prev;
              if (next) {
                setIsDockCollapsed(true);
                setIsSplitCompareMode(false);
              }
              return next;
            });
          }}
          isSplitCompareMode={isSplitCompareMode}
          onToggleSplitCompareMode={handleToggleSplitCompareMode}
          compareOutfitB={compareOutfitB}
          outfitHistory={outfitHistory}
          activeHistoryIdA={activeHistoryId}
          activeHistoryIdB={activeHistoryIdB}
          onSelectCompareHistoryA={handleApplyHistoryEntry}
          onSelectCompareHistoryB={handleSelectCompareHistoryB}
          onUpdateOutfitA={(next) => {
            setOutfit(next);
            setActiveHistoryId(null);
          }}
          onUpdateCompareOutfitB={(next) => {
            setCompareOutfitB(next);
            setActiveHistoryIdB(null);
          }}
          weatherEffect={weatherEffect}
          onUpdateWeatherEffect={setWeatherEffect}
          lastAiPoseResult={lastAiPoseResult}
          videoWalkthroughTrigger={videoWalkthroughTrigger}
          exportGlbTrigger={exportGlbTrigger}
          exportUsdzTrigger={exportUsdzTrigger}
        />

        <BottomControlDock
          activeTab={activeTab}
          onSelectTab={setActiveTab}
          isCollapsed={isDockCollapsed}
          onToggleCollapse={() => setIsDockCollapsed((prev) => !prev)}
          body={body}
          onUpdateHeightWeight={handleUpdateHeightWeight}
          onUpdateBodyField={handleUpdateBodyField}
          outfit={outfit}
          onUpdateOutfit={setOutfit}
          fitAnalysis={fitAnalysis}
          outfitHistory={outfitHistory}
          activeHistoryId={activeHistoryId}
          activeHistoryIdB={activeHistoryIdB}
          isSplitCompareMode={isSplitCompareMode}
          onToggleSplitCompareMode={handleToggleSplitCompareMode}
          onSaveCurrentOutfit={handleSaveCurrentOutfit}
          onApplyHistoryEntry={handleApplyHistoryEntry}
          onSelectCompareHistoryB={handleSelectCompareHistoryB}
          onDeleteHistoryEntry={handleDeleteHistoryEntry}
          onClearHistory={handleClearHistory}
          posePreset={posePreset}
          onSelectPosePreset={handleSelectPosePreset}
          selectedJoint={selectedJoint}
          onSelectJoint={setSelectedJoint}
          jointRotations={jointRotations}
          onUpdateJointRotation={handleUpdateJointRotation}
          onResetCurrentJoint={handleResetCurrentJoint}
          onStandStillPose={handleStandStillPose}
          cameraPreset={cameraPreset}
          onSelectCameraPreset={handleSelectCameraPreset}
          lightingPreset={lightingPreset}
          onSelectLightingPreset={setLightingPreset}
          showMeasurementTape={showMeasurementTape}
          onToggleMeasurementTape={() => setShowMeasurementTape((prev) => !prev)}
          weatherEffect={weatherEffect}
          onUpdateWeatherEffect={setWeatherEffect}
          onGenerateAiPose={handleGenerateAiPose}
          isGeneratingPose={isGeneratingPose}
          lastAiPoseResult={lastAiPoseResult}
        />
      </main>
    </div>
  );
}

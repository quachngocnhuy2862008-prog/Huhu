import 'dotenv/config';
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(express.json({ limit: '2mb' }));

const eulerSchema = {
  type: Type.OBJECT,
  properties: {
    x: { type: Type.NUMBER, description: 'Pitch rotation in degrees (Gập / Duỗi)' },
    y: { type: Type.NUMBER, description: 'Yaw rotation in degrees (Xoay trục)' },
    z: { type: Type.NUMBER, description: 'Roll rotation in degrees (Dang / Nghiêng)' },
  },
  required: ['x', 'y', 'z'],
};

const poseResponseSchema = {
  type: Type.OBJECT,
  properties: {
    poseTitle: {
      type: Type.STRING,
      description: 'Short Vietnamese title of the generated pose',
    },
    explanation: {
      type: Type.STRING,
      description: 'Concise Vietnamese explanation of the joint adjustments made',
    },
    isSeated: {
      type: Type.BOOLEAN,
      description: 'True if the pose involves sitting (e.g. ngồi ghế, ngồi bắt chéo chân)',
    },
    rotations: {
      type: Type.OBJECT,
      properties: {
        head: eulerSchema,
        neck: eulerSchema,
        chest: eulerSchema,
        spine: eulerSchema,
        pelvis: eulerSchema,
        leftShoulder: eulerSchema,
        leftElbow: eulerSchema,
        leftWrist: eulerSchema,
        rightShoulder: eulerSchema,
        rightElbow: eulerSchema,
        rightWrist: eulerSchema,
        leftHip: eulerSchema,
        leftKnee: eulerSchema,
        leftAnkle: eulerSchema,
        rightHip: eulerSchema,
        rightKnee: eulerSchema,
        rightAnkle: eulerSchema,
      },
      required: [
        'head',
        'neck',
        'chest',
        'spine',
        'pelvis',
        'leftShoulder',
        'leftElbow',
        'leftWrist',
        'rightShoulder',
        'rightElbow',
        'rightWrist',
        'leftHip',
        'leftKnee',
        'leftAnkle',
        'rightHip',
        'rightKnee',
        'rightAnkle',
      ],
    },
  },
  required: ['poseTitle', 'explanation', 'isSeated', 'rotations'],
};

const SYSTEM_INSTRUCTION = `Bạn là hệ thống điều khiển khung xương 3D (17 khớp Euler X, Y, Z tính bằng độ trong không gian Root) cho người mẫu thời trang 3D (ReadyPlayerMe / Mixamo rig).
Quy ước hệ trục từng khớp xương từ tư thế đứng tự nhiên (0, 0, 0):
- head (Đầu): x âm = ngước lên, x dương = cúi xuống (-35..35); y dương = nhìn sang trái của người mẫu, y âm = nhìn sang phải (-60..60); z = nghiêng đầu (-25..25).
- neck (Cổ): x (-20..20), y (-35..35), z (-15..15).
- chest (Ngực trên): x âm = ưỡn ngực thẳng, x dương = gập người về trước (-25..30); y = xoay vai (-40..40); z = nghiêng ngực (-20..20).
- spine (Eo): x (-25..35), y (-35..35), z (-20..20).
- pelvis (Hông): x (-20..20), y (-45..45), z (-15..15).
- leftShoulder (Vai Trái): x âm = đưa tay trái về trước (-90..45), y (-30..30), z dương = dang/giơ tay trái sang ngang và lên cao (-15..120). Khi chống hông trái: { x: 8, y: 0, z: 26 }. Khi giơ cao tay trái ăn mừng: { x: -20, y: 10, z: 112 }.
- leftElbow (Khuỷu Tay Trái): LƯU Ý tổng leftShoulder.x + leftElbow.x không được âm quá -130 độ. Khi chống hông trái: { x: -24, y: 0, z: -56 }. Khi khoanh tay trước ngực: leftShoulder { x: -22, y: 12, z: -4 }, leftElbow { x: -24, y: 10, z: -66 }.
- rightShoulder (Vai Phải): x âm = đưa tay phải về trước (-90..45), y (-30..30), z âm = dang/giơ tay phải sang ngang và lên cao (-120..15). Khi chống hông phải: { x: 8, y: 0, z: -26 }. Khi giơ cao tay phải ăn mừng: { x: -20, y: -10, z: -112 }.
- rightElbow (Khuỷu Tay Phải): LƯU Ý tổng rightShoulder.x + rightElbow.x không được âm quá -130 độ. Khi chống hông phải: { x: -24, y: 0, z: 56 }. Khi khoanh tay trước ngực: rightShoulder { x: -18, y: -12, z: 4 }, rightElbow { x: -20, y: -10, z: 64 }. Khi vẫy tay chào: rightShoulder { x: -24, y: -12, z: -42 }, rightElbow { x: -72, y: 0, z: -12 }.
- leftWrist, rightWrist: x (-40..40), y (-25..25), z (-30..30).
- leftHip, rightHip (Đùi/Hông): x âm = nâng đùi lên phía trước (ngồi ghế x = -80 đến -98), x dương = đưa chân ra sau (-105..40); y = xoay đùi (-25..25); z = dạng/khép chân (khi ngồi bắt chéo chân trái qua chân phải: leftHip { x: -98, y: -8, z: -12 }, leftKnee { x: 92, y: 0, z: 10 }, rightHip { x: -80, y: 4, z: -4 }, rightKnee { x: 84, y: 0, z: 0 }).
- leftKnee, rightKnee (Đầu Gối): x dương = gập đầu gối về phía sau (đứng thẳng x = 0, ngồi ghế x = 84 đến 92, khoảng 0..130).
- leftAnkle, rightAnkle (Cổ Chân): x (-35..35), y (-20..20), z (-15..15).
Hãy tạo thông số 17 khớp tự nhiên, cân đối, đúng giải phẫu học theo mô tả của người dùng.`;

app.post('/api/pose-ai', async (req, res) => {
  try {
    const prompt = String(req.body?.prompt || '').trim();
    if (!prompt) {
      res.status(400).json({ error: 'Vui lòng nhập mô tả tư thế.' });
      return;
    }

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(503).json({
        error: 'GEMINI_API_KEY_NOT_CONFIGURED',
      });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Mô tả tư thế người mẫu 3D: "${prompt}". Hãy trả về JSON thông số góc xoay 17 khớp xương.`,
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
        responseMimeType: 'application/json',
        responseSchema: poseResponseSchema,
      },
    });

    const jsonText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(jsonText);
    res.json(parsed);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Lỗi kết nối Gemini API';
    res.status(500).json({ error: msg });
  }
});

const colorPaletteItemSchema = {
  type: Type.OBJECT,
  properties: {
    id: { type: Type.STRING },
    scheme: {
      type: Type.STRING,
      description: 'complementary | analogous | triadic | split_complementary | monochromatic',
    },
    schemeLabel: {
      type: Type.STRING,
      description: 'Vietnamese name of the color theory harmony',
    },
    paletteName: {
      type: Type.STRING,
      description: 'Creative Vietnamese fashion palette title',
    },
    theoryExplanation: {
      type: Type.STRING,
      description: 'Concise Vietnamese explanation of why this color harmony works on the outfit',
    },
    topColorHex: { type: Type.STRING, description: '6-digit HEX color e.g. #F3EFE6' },
    outerwearColorHex: { type: Type.STRING, description: '6-digit HEX color e.g. #1E293B' },
    bottomColorHex: { type: Type.STRING, description: '6-digit HEX color e.g. #2B4C7E' },
    footwearColorHex: { type: Type.STRING, description: '6-digit HEX color e.g. #F8FAFC' },
    accessoryColorHex: { type: Type.STRING, description: '6-digit HEX color e.g. #78350F' },
    accessoryMetalHex: { type: Type.STRING, description: '6-digit HEX color e.g. #D4AF37' },
    swatches: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          role: { type: Type.STRING },
          name: { type: Type.STRING },
          hex: { type: Type.STRING },
        },
        required: ['role', 'name', 'hex'],
      },
    },
  },
  required: [
    'id',
    'scheme',
    'schemeLabel',
    'paletteName',
    'theoryExplanation',
    'topColorHex',
    'outerwearColorHex',
    'bottomColorHex',
    'footwearColorHex',
    'accessoryColorHex',
    'accessoryMetalHex',
    'swatches',
  ],
};

const colorPaletteResponseSchema = {
  type: Type.OBJECT,
  properties: {
    palettes: {
      type: Type.ARRAY,
      items: colorPaletteItemSchema,
    },
  },
  required: ['palettes'],
};

app.post('/api/color-palette', async (req, res) => {
  try {
    const primaryColorHex = String(req.body?.primaryColorHex || '#1E293B').trim();
    const anchorCategory = String(req.body?.anchorCategory || 'top').trim();
    const fabric = String(req.body?.fabric || 'cotton').trim();
    const genderProfile = String(req.body?.genderProfile || 'female').trim();

    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(503).json({
        error: 'GEMINI_API_KEY_NOT_CONFIGURED',
      });
      return;
    }

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Người mẫu (${genderProfile}) đang mặc trang phục chính (${anchorCategory}) có màu chủ đạo ${primaryColorHex} trên chất liệu ${fabric}. Hãy tạo 5 bảng phối màu thời trang cao cấp theo lý thuyết bánh xe màu sắc:
1. complementary (Tương phản bổ túc 180°)
2. analogous (Tương đồng liền kề ±30°)
3. triadic (Tam giác cân 120°)
4. split_complementary (Bổ túc tách đôi 150°/210°)
5. monochromatic (Đơn sắc chuyển sắc độ Ton-sur-Ton)
Giữ nguyên màu chủ đạo ${primaryColorHex} cho món đồ chính (${anchorCategory}) và gợi ý mã màu HEX tinh tế, sang trọng, thực tế cho các lớp còn lại (topColorHex, outerwearColorHex, bottomColorHex, footwearColorHex, accessoryColorHex, accessoryMetalHex).`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: colorPaletteResponseSchema,
      },
    });

    const jsonText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(jsonText);
    res.json(parsed);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Lỗi kết nối Gemini API';
    res.status(500).json({ error: msg });
  }
});

const aiStylistItemSchema = {
  type: Type.OBJECT,
  properties: {
    id: { type: Type.STRING },
    title: {
      type: Type.STRING,
      description: 'Vietnamese editorial title of the full outfit lookbook',
    },
    trendName: {
      type: Type.STRING,
      description: 'Vietnamese fashion trend name',
    },
    seasonTag: {
      type: Type.STRING,
      description: 'e.g. FW26 / SS27 Runway Trend',
    },
    styleCompatibilityScore: {
      type: Type.NUMBER,
      description: 'Compatibility score 88-99 based on user saved style history',
    },
    savedStyleMatchReason: {
      type: Type.STRING,
      description: 'Vietnamese explanation of how this full outfit matches the user saved outfit history and body shape',
    },
    trendAnalysis: {
      type: Type.STRING,
      description: 'Vietnamese explanation of why this silhouette, fabric, and color palette are trending now',
    },
    imagePrompt: {
      type: Type.STRING,
      description: 'Detailed fashion editorial lookbook description of the outfit, fabrics, lighting, and silhouette',
    },
    recommendedPose: {
      type: Type.STRING,
      description: 'lookbook_pose | catwalk_walk | editorial_crossed | natural_idle',
    },
    topStyleId: {
      type: Type.STRING,
      description: 'silk_blouse_bow | baby_tee | off_shoulder_knit | corset_top | silk_camisole | puff_blouse | female_turtleneck | oxford_shirt | crewneck_tee | polo_shirt | turtleneck_knit',
    },
    topColorHex: { type: Type.STRING, description: '6-digit HEX color' },
    topFabric: {
      type: Type.STRING,
      description: 'cotton | linen | silk | fleece | denim | leather',
    },
    outerwearStyleId: {
      type: Type.STRING,
      description: 'none | tailored_blazer | bomber_jacket | biker_leather | trench_coat | gilet_vest | denim_jacket',
    },
    outerwearColorHex: { type: Type.STRING, description: '6-digit HEX color' },
    outerwearFabric: {
      type: Type.STRING,
      description: 'fleece | linen | leather | denim | cotton | silk',
    },
    bottomStyleId: {
      type: Type.STRING,
      description: 'tailored_trousers | pleated_maxi_skirt | aline_skirt | pencil_skirt | slim_jeans | female_cargo_pants | male_dress_trousers | male_denim_jeans | cargo_pants | male_chino_khaki',
    },
    bottomColorHex: { type: Type.STRING, description: '6-digit HEX color' },
    bottomFabric: {
      type: Type.STRING,
      description: 'fleece | denim | linen | silk | cotton | leather',
    },
    footwearStyleId: {
      type: Type.STRING,
      description: 'minimal_sneakers | chunky_dad_sneakers | chelsea_boots | pointed_heels | penny_loafers',
    },
    footwearColorHex: { type: Type.STRING, description: '6-digit HEX color' },
    watchStyleId: {
      type: Type.STRING,
      description: 'none | luxury_chronograph | minimal_dress_watch | smart_watch_ultra | vintage_gold_tank',
    },
    handbagStyleId: {
      type: Type.STRING,
      description: 'none | paris_saddle_bag | mini_top_handle | quilted_chain_flap | structured_tote | crossbody_messenger',
    },
    sunglassesStyleId: {
      type: Type.STRING,
      description: 'none | classic_aviator | retro_cat_eye | oversized_square | cyber_shield_sport | vintage_round_metal',
    },
    accessoryColorHex: { type: Type.STRING, description: '6-digit HEX color' },
    accessoryMetalHex: { type: Type.STRING, description: '6-digit HEX color' },
  },
  required: [
    'id',
    'title',
    'trendName',
    'seasonTag',
    'styleCompatibilityScore',
    'savedStyleMatchReason',
    'trendAnalysis',
    'imagePrompt',
    'recommendedPose',
    'topStyleId',
    'topColorHex',
    'topFabric',
    'outerwearStyleId',
    'outerwearColorHex',
    'outerwearFabric',
    'bottomStyleId',
    'bottomColorHex',
    'bottomFabric',
    'footwearStyleId',
    'footwearColorHex',
    'watchStyleId',
    'handbagStyleId',
    'sunglassesStyleId',
    'accessoryColorHex',
    'accessoryMetalHex',
  ],
};

const aiStylistResponseSchema = {
  type: Type.OBJECT,
  properties: {
    userStyleProfileSummary: {
      type: Type.STRING,
      description: 'Vietnamese summary of the user saved fashion preferences, colors, and silhouette DNA',
    },
    recommendations: {
      type: Type.ARRAY,
      items: aiStylistItemSchema,
    },
  },
  required: ['userStyleProfileSummary', 'recommendations'],
};

app.post('/api/ai-stylist', async (req, res) => {
  try {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      res.status(503).json({
        error: 'GEMINI_API_KEY_NOT_CONFIGURED',
      });
      return;
    }

    const trendId = String(req.body?.trendId || 'quiet_luxury').trim();
    const trendLabel = String(req.body?.trendLabel || 'Quiet Luxury & Old Money').trim();
    const customPrompt = String(req.body?.customPrompt || '').trim();
    const genderProfile = String(req.body?.genderProfile || 'female').trim();
    const bodyShapeName = String(req.body?.bodyShapeName || 'Cân đối').trim();
    const heightCm = Number(req.body?.heightCm || 170);
    const weightKg = Number(req.body?.weightKg || 56);
    const savedOutfitsSummary = String(
      req.body?.savedOutfitsSummary || 'Ưa chuộng phong cách thanh lịch, phom dáng vừa vặn'
    ).trim();

    const ai = new GoogleGenAI({
      apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: `Bạn là Giám đốc Sáng tạo & AI Fashion Stylist cao cấp.
Thông tin người mẫu:
- Giới tính: ${genderProfile === 'male' ? 'Nam' : 'Nữ'}, Chiều cao: ${heightCm}cm, Cân nặng: ${weightKg}kg, Dáng người: ${bodyShapeName}.
- Phong cách & Lịch sử phối đồ đã lưu của người dùng: ${savedOutfitsSummary}.
- Xu hướng thời trang chủ đạo yêu cầu: ${trendLabel} (${trendId}).
${customPrompt ? `- Yêu cầu cá nhân hóa thêm từ người dùng: "${customPrompt}".` : ''}

Hãy thiết kế 3 bộ trang phục trọn bộ (Full Lookbook: Áo trong + Áo khoác ngoài + Quần/Váy + Giày + Đồng hồ + Túi xách + Kính mát) kết hợp hài hòa giữa xu hướng thời trang hiện tại (${trendLabel}) và DNA phong cách đã lưu của người dùng. Trả về đúng mã HEX 6 ký tự và đúng các styleId 3D được liệt kê trong schema.`,
      config: {
        responseMimeType: 'application/json',
        responseSchema: aiStylistResponseSchema,
      },
    });

    const jsonText = (response.text ?? '{}').trim();
    const parsed = JSON.parse(jsonText);
    res.json(parsed);
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Lỗi kết nối Gemini API';
    res.status(500).json({ error: msg });
  }
});

async function startServer() {
  const PORT = Number(process.env.PORT) || 3000;

  if (process.env.NODE_ENV === 'production') {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        allowedHosts: true,
        hmr: process.env.DISABLE_HMR !== 'true',
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Smart Wardrobe server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();

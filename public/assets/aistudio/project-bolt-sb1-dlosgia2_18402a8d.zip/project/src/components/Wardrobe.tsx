import { useEffect, useMemo, useState } from 'react';
import {
  Upload,
  Shirt,
  Trash2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  X,
} from 'lucide-react';
import type { Profile, ClothingItem } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import {
  analyzeBody,
  computeProportions,
  type BodyType,
} from '@/lib/bodyAnalysis';
import { scoreFit, type FitResult } from '@/lib/fitScore';
import { OCCASIONS, occasionInfo, type Occasion } from '@/lib/occasions';
import Mannequin from './Mannequin';
import MannequinStudio from './MannequinStudio';

interface Props {
  profile: Profile;
  occasion: Occasion;
  onReset: () => void;
}

const CATEGORIES: { value: ClothingItem['category']; label: string }[] = [
  { value: 'top', label: 'Áo' },
  { value: 'bottom', label: 'Quần/Váy' },
  { value: 'dress', label: 'Đầm liền' },
  { value: 'outerwear', label: 'Áo khoác' },
  { value: 'other', label: 'Khác' },
];

const COLORS = ['black', 'navy', 'white', 'gray', 'red', 'blue', 'green', 'beige', 'brown', 'pink', 'yellow', 'orange'];

export default function Wardrobe({ profile, occasion, onReset }: Props) {
  const [items, setItems] = useState<ClothingItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const [tryOnItem, setTryOnItem] = useState<ClothingItem | null>(null);
  const [showUpload, setShowUpload] = useState(false);
  const [showOccasionPicker, setShowOccasionPicker] = useState(false);
  const [currentOccasion, setCurrentOccasion] = useState<Occasion>(occasion);

  const analysis = useMemo(
    () =>
      analyzeBody({
        gender: profile.gender,
        height_cm: profile.height_cm,
        weight_kg: profile.weight_kg,
        waist_cm: profile.waist_cm,
        hip_cm: profile.hip_cm,
        bust_cm: profile.bust_cm,
      }),
    [profile]
  );

  const proportions = useMemo(
    () =>
      computeProportions(
        profile.gender,
        profile.height_cm,
        profile.weight_kg,
        profile.waist_cm,
        profile.hip_cm,
        profile.bust_cm
      ),
    [profile]
  );

  useEffect(() => {
    loadItems();
  }, []);

  async function loadItems() {
    setLoading(true);
    const { data } = await supabase
      .from('clothes')
      .select('*')
      .order('created_at', { ascending: false });
    setItems((data as ClothingItem[]) || []);
    setLoading(false);
  }

  async function handleUpload(file: File, category: ClothingItem['category'], color: string, label: string) {
    setUploading(true);
    const ext = file.name.split('.').pop() || 'png';
    const path = `${crypto.randomUUID()}.${ext}`;
    const { error: upErr } = await supabase.storage
      .from('clothing')
      .upload(path, file, { cacheControl: '3600', upsert: false });
    if (upErr) {
      setUploading(false);
      return null;
    }
    const { data: pub } = supabase.storage.from('clothing').getPublicUrl(path);
    const { data: row, error } = await supabase
      .from('clothes')
      .insert({
        image_path: pub.publicUrl,
        category,
        color: color || null,
        label: label || file.name,
      })
      .select()
      .maybeSingle();
    setUploading(false);
    if (error || !row) return null;
    setItems((prev) => [row as ClothingItem, ...prev]);
    setShowUpload(false);
    return row as ClothingItem;
  }

  async function handleDelete(item: ClothingItem) {
    // remove from storage if it's one of ours (path contains uuid.ext)
    const url = item.image_path;
    const fileName = url.split('/').pop();
    if (fileName) {
      await supabase.storage.from('clothing').remove([fileName]);
    }
    await supabase.from('clothes').delete().eq('id', item.id);
    setItems((prev) => prev.filter((i) => i.id !== item.id));
    if (tryOnItem?.id === item.id) setTryOnItem(null);
  }

  async function handleTryOnScore(item: ClothingItem) {
    const fit = scoreFit(item.category, item.color || undefined, analysis.bodyType as BodyType, currentOccasion);
    const { error } = await supabase
      .from('clothes')
      .update({ fit_score: fit.score, fit_notes: fit.notes.join(' | ') })
      .eq('id', item.id);
    if (!error) {
      setItems((prev) =>
        prev.map((i) => (i.id === item.id ? { ...i, fit_score: fit.score, fit_notes: fit.notes.join(' | ') } : i))
      );
      setTryOnItem((prev) => (prev && prev.id === item.id ? { ...prev, fit_score: fit.score, fit_notes: fit.notes.join(' | ') } : prev));
    }
    return fit;
  }

  const tryOnFit = useMemo(() => {
    if (!tryOnItem) return null;
    return scoreFit(tryOnItem.category, tryOnItem.color || undefined, analysis.bodyType as BodyType, currentOccasion);
  }, [tryOnItem, analysis.bodyType, currentOccasion]);

  const occInfo = occasionInfo(currentOccasion);

  return (
    <div className="min-h-screen bg-gradient-to-b from-stone-50 via-rose-50/40 to-amber-50/40">
      <Header profile={profile} analysis={analysis} occasion={currentOccasion} onReset={onReset} onPickOccasion={() => setShowOccasionPicker(true)} />

      <main className="mx-auto max-w-6xl px-4 pb-16">
        {/* suggestions */}
        <section className="mb-8 rounded-3xl border border-rose-100 bg-white/80 p-6 shadow-sm backdrop-blur">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-rose-600">
              <Sparkles className="h-5 w-5" />
              <h2 className="text-lg font-semibold">Gợi ý cho dáng "{analysis.bodyTypeLabel}" — {occInfo.emoji} {occInfo.label}</h2>
            </div>
            <button
              onClick={() => setShowOccasionPicker(true)}
              className="rounded-lg border border-rose-200 px-3 py-1.5 text-sm font-medium text-rose-500 hover:bg-rose-50"
            >
              Đổi hoàn cảnh
            </button>
          </div>
          <p className="mt-2 text-sm text-stone-500">{occInfo.description}</p>
          <ul className="mt-4 grid gap-3 md:grid-cols-2">
            {analysis.suggestions.map((s, i) => (
              <li key={i} className="flex gap-2 rounded-xl bg-rose-50/60 px-4 py-3 text-sm text-stone-700">
                <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-rose-400" />
                {s}
              </li>
            ))}
          </ul>
        </section>

        {/* 3D mannequin studio */}
        <section className="mb-8">
          <MannequinStudio profile={profile} />
        </section>

        {/* try-on panel */}
        <section className="mb-8">
          <div className="rounded-3xl border border-stone-200 bg-white/80 p-6 shadow-sm backdrop-blur">
            {tryOnItem ? (
              <TryOnPanel
                item={tryOnItem}
                proportions={proportions}
                gender={profile.gender}
                fit={tryOnFit}
                occasion={currentOccasion}
                onClose={() => setTryOnItem(null)}
                onScore={() => handleTryOnScore(tryOnItem)}
              />
            ) : (
              <div className="flex h-full flex-col items-center justify-center py-16 text-center text-stone-400">
                <Shirt className="mb-3 h-10 w-10" />
                <p className="text-sm">Chọn một món đồ từ tủ quần áo bên dưới để thử lên ma-nơ-canh.</p>
              </div>
            )}
          </div>
        </section>

        {/* wardrobe */}
        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold text-stone-700">Tủ quần áo của bạn</h2>
            <button
              onClick={() => setShowUpload(true)}
              className="flex items-center gap-2 rounded-xl bg-stone-800 px-4 py-2 text-sm font-semibold text-white shadow hover:bg-stone-900"
            >
              <Upload className="h-4 w-4" /> Tải ảnh quần áo
            </button>
          </div>

          {loading ? (
            <div className="py-16 text-center text-stone-400">Đang tải...</div>
          ) : items.length === 0 ? (
            <EmptyWardrobe onUpload={() => setShowUpload(true)} />
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
              {items.map((item) => (
                <ClothingCard
                  key={item.id}
                  item={item}
                  onTryOn={() => setTryOnItem(item)}
                  onDelete={() => handleDelete(item)}
                />
              ))}
            </div>
          )}
        </section>
      </main>

      {showUpload && (
        <UploadModal
          onUpload={handleUpload}
          onClose={() => setShowUpload(false)}
          uploading={uploading}
        />
      )}

      {showOccasionPicker && (
        <OccasionModal
          current={currentOccasion}
          onPick={(o) => {
            setCurrentOccasion(o);
            setShowOccasionPicker(false);
          }}
          onClose={() => setShowOccasionPicker(false)}
        />
      )}
    </div>
  );
}

/* ---------- header ---------- */

function Header({
  profile,
  analysis,
  occasion,
  onReset,
  onPickOccasion,
}: {
  profile: Profile;
  analysis: ReturnType<typeof analyzeBody>;
  occasion: Occasion;
  onReset: () => void;
  onPickOccasion: () => void;
}) {
  const occ = occasionInfo(occasion);
  return (
    <header className="border-b border-rose-100 bg-white/70 backdrop-blur">
      <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-3 sm:py-4">
        <div>
          <div className="text-xs text-stone-400 sm:text-sm">Xin chào,</div>
          <div className="text-lg font-bold text-stone-800 sm:text-xl">{profile.name}</div>
        </div>
        <div className="flex flex-wrap items-center gap-2 text-xs text-stone-600 sm:gap-3 sm:text-sm">
          <Pill label="BMI" value={String(analysis.bmi)} />
          <Pill label="Dáng" value={analysis.bodyTypeLabel} />
          <button
            onClick={onPickOccasion}
            className="rounded-lg bg-rose-50 px-2.5 py-1.5 text-xs hover:bg-rose-100 sm:px-3"
          >
            <span className="text-rose-400">Hoàn cảnh: </span>
            <span className="font-semibold text-stone-700">{occ.emoji} {occ.label}</span>
          </button>
        </div>
        <button
          onClick={onReset}
          className="flex items-center gap-1.5 rounded-lg border border-stone-200 px-3 py-1.5 text-sm text-stone-500 hover:bg-stone-50"
        >
          <RotateCcw className="h-3.5 w-3.5" />&nbsp;Đo lại
        </button>
      </div>
    </header>
  );
}

function Pill({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-rose-50 px-3 py-1.5">
      <span className="text-xs text-rose-400">{label}: </span>
      <span className="font-semibold text-stone-700">{value}</span>
    </div>
  );
}

/* ---------- clothing card ---------- */

function ClothingCard({
  item,
  onTryOn,
  onDelete,
}: {
  item: ClothingItem;
  onTryOn: () => void;
  onDelete: () => void;
}) {
  const catLabel = CATEGORIES.find((c) => c.value === item.category)?.label || item.category;
  return (
    <div className="group relative overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm transition hover:shadow-md">
      <button onClick={onTryOn} className="block w-full">
        <img
          src={item.image_path}
          alt={item.label}
          className="h-44 w-full object-cover transition group-hover:scale-105"
        />
      </button>
      <div className="p-3">
        <div className="flex items-center justify-between">
          <div className="truncate text-sm font-semibold text-stone-700">{item.label}</div>
          <button onClick={onDelete} className="text-stone-300 hover:text-red-500">
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-1 flex items-center gap-2 text-xs text-stone-400">
          <span>{catLabel}</span>
          {item.color && <span>· {item.color}</span>}
        </div>
        {item.fit_score != null && (
          <div className="mt-2 flex items-center gap-1.5">
            <ScoreBadge score={item.fit_score} />
          </div>
        )}
      </div>
    </div>
  );
}

function ScoreBadge({ score }: { score: number }) {
  const color =
    score >= 85 ? 'bg-emerald-100 text-emerald-700' :
    score >= 72 ? 'bg-sky-100 text-sky-700' :
    score >= 55 ? 'bg-amber-100 text-amber-700' :
    'bg-rose-100 text-rose-700';
  return (
    <span className={`rounded-full px-2 py-0.5 text-xs font-semibold ${color}`}>
      Độ phù hợp: {score}/100
    </span>
  );
}

/* ---------- try-on panel ---------- */

function TryOnPanel({
  item,
  proportions,
  gender,
  fit,
  occasion,
  onClose,
  onScore,
}: {
  item: ClothingItem;
  proportions: ReturnType<typeof computeProportions>;
  gender: 'male' | 'female';
  fit: FitResult | null;
  occasion: Occasion;
  onClose: () => void;
  onScore: () => void;
}) {
  return (
    <div>
      <div className="flex items-start justify-between">
        <div>
          <div className="text-sm text-stone-400">Đang thử</div>
          <div className="text-lg font-bold text-stone-800">{item.label}</div>
        </div>
        <button onClick={onClose} className="text-stone-400 hover:text-stone-600">
          <X className="h-5 w-5" />
        </button>
      </div>

      <div className="mt-4 grid gap-4 sm:grid-cols-2">
        <div className="rounded-2xl bg-gradient-to-b from-white to-stone-50 p-3">
          <Mannequin
            proportions={proportions}
            gender={gender}
            clothingImage={item.image_path}
            clothingCategory={item.category}
            className="mx-auto h-[360px] w-full max-w-[260px]"
          />
          <div className="mt-1 text-center text-xs text-stone-400">Thử cho: {occasionInfo(occasion).emoji} {occasionInfo(occasion).label}</div>
        </div>
        <div className="flex flex-col">
          <img src={item.image_path} alt={item.label} className="h-40 w-full rounded-2xl object-cover" />
          <div className="mt-4 space-y-2">
            {fit && (
              <>
                <ScoreBadge score={fit.score} />
                <div className="rounded-xl bg-stone-50 p-3 text-sm text-stone-600">
                  <div className="mb-1 font-semibold text-stone-700">Nhận xét:</div>
                  <ul className="space-y-1">
                    {fit.notes.map((n, i) => (
                      <li key={i} className="flex gap-2">
                        <Sparkles className="mt-0.5 h-3.5 w-3.5 shrink-0 text-rose-400" /> {n}
                      </li>
                    ))}
                  </ul>
                </div>
              </>
            )}
          </div>
          <button
            onClick={onScore}
            className="mt-auto flex items-center justify-center gap-2 rounded-xl bg-rose-500 py-3 font-semibold text-white shadow hover:bg-rose-600"
          >
            <Sparkles className="h-4 w-4" /> Chấm độ phù hợp
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------- empty ---------- */

function EmptyWardrobe({ onUpload }: { onUpload: () => void }) {
  return (
    <div className="rounded-3xl border-2 border-dashed border-stone-200 py-16 text-center">
      <Shirt className="mx-auto mb-3 h-12 w-12 text-stone-300" />
      <p className="text-stone-500">Chưa có món đồ nào trong tủ.</p>
      <button
        onClick={onUpload}
        className="mt-4 inline-flex items-center gap-2 rounded-xl bg-stone-800 px-5 py-2.5 text-sm font-semibold text-white hover:bg-stone-900"
      >
        <Upload className="h-4 w-4" /> Tải ảnh quần áo lên
      </button>
    </div>
  );
}

/* ---------- upload modal ---------- */

function UploadModal({
  onUpload,
  onClose,
  uploading,
}: {
  onUpload: (file: File, category: ClothingItem['category'], color: string, label: string) => Promise<ClothingItem | null>;
  onClose: () => void;
  uploading: boolean;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [category, setCategory] = useState<ClothingItem['category']>('top');
  const [color, setColor] = useState('');
  const [label, setLabel] = useState('');
  const [err, setErr] = useState<string | null>(null);

  function onPick(f: File | null) {
    setFile(f);
    if (f) {
      setPreview(URL.createObjectURL(f));
      if (!label) setLabel(f.name.replace(/\.[^.]+$/, ''));
    } else {
      setPreview(null);
    }
  }

  async function submit() {
    if (!file) {
      setErr('Vui lòng chọn một ảnh.');
      return;
    }
    setErr(null);
    const res = await onUpload(file, category, color, label);
    if (!res) setErr('Tải lên thất bại. Vui lòng thử lại.');
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div
        className="w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-stone-800">Tải ảnh quần áo lên</h3>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-600">
            <X className="h-5 w-5" />
          </button>
        </div>

        <label className="mt-4 block">
          <div className="flex h-40 cursor-pointer items-center justify-center rounded-2xl border-2 border-dashed border-stone-200 bg-stone-50 text-stone-400 hover:border-rose-300 hover:bg-rose-50/40">
            {preview ? (
              <img src={preview} alt="preview" className="h-full w-full rounded-2xl object-cover" />
            ) : (
              <div className="text-center">
                <Upload className="mx-auto mb-2 h-8 w-8" />
                <span className="text-sm">Nhấn để chọn ảnh</span>
              </div>
            )}
          </div>
          <input
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => onPick(e.target.files?.[0] || null)}
          />
        </label>

        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <div>
            <label className="text-xs text-stone-400">Tên món đồ</label>
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="VD: Áo sơ mi trắng"
              className="mt-1 w-full rounded-lg border border-stone-200 px-3 py-2 text-sm outline-none focus:border-rose-400"
            />
          </div>
          <div>
            <label className="text-xs text-stone-400">Loại</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value as ClothingItem['category'])}
              className="mt-1 w-full rounded-lg border border-stone-200 px-3 py-2 text-sm outline-none focus:border-rose-400"
            >
              {CATEGORIES.map((c) => (
                <option key={c.value} value={c.value}>{c.label}</option>
              ))}
            </select>
          </div>
          <div className="sm:col-span-2">
            <label className="text-xs text-stone-400">Màu chủ đạo</label>
            <select
              value={color}
              onChange={(e) => setColor(e.target.value)}
              className="mt-1 w-full rounded-lg border border-stone-200 px-3 py-2 text-sm outline-none focus:border-rose-400"
            >
              <option value="">— không chọn —</option>
              {COLORS.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>
        </div>

        {err && (
          <div className="mt-3 flex items-center gap-2 rounded-lg bg-rose-50 px-3 py-2 text-sm text-rose-600">
            <AlertCircle className="h-4 w-4" /> {err}
          </div>
        )}

        <button
          onClick={submit}
          disabled={uploading}
          className="mt-5 flex w-full items-center justify-center gap-2 rounded-xl bg-rose-500 py-3 font-semibold text-white shadow hover:bg-rose-600 disabled:opacity-40"
        >
          {uploading ? 'Đang tải...' : 'Tải lên & lưu'}
        </button>
      </div>
    </div>
  );
}

/* ---------- occasion modal ---------- */

function OccasionModal({
  current,
  onPick,
  onClose,
}: {
  current: Occasion;
  onPick: (o: Occasion) => void;
  onClose: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={onClose}>
      <div
        className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-stone-800">Chọn hoàn cảnh phối đồ</h3>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-600">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="mt-4 grid grid-cols-2 gap-3">
          {OCCASIONS.map((o) => (
            <button
              key={o.value}
              onClick={() => onPick(o.value)}
              className={`flex flex-col items-center gap-1 rounded-xl border-2 px-2 py-4 text-sm font-semibold transition ${
                current === o.value
                  ? 'border-rose-500 bg-rose-50 text-rose-600'
                  : 'border-stone-200 bg-white text-stone-500 hover:border-rose-300'
              }`}
            >
              <span className="text-3xl">{o.emoji}</span>
              {o.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

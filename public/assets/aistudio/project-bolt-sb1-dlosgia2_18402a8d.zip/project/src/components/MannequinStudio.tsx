import { useState } from 'react';
import { Maximize2, Minimize2, ExternalLink, Info } from 'lucide-react';
import type { Profile } from '@/lib/supabase';

interface Props {
  profile: Profile;
}

const STUDIO_URL = 'https://ma-n-canh.ai.studio/';

export default function MannequinStudio({ profile }: Props) {
  const [fullscreen, setFullscreen] = useState(false);

  // Pass user data via URL hash so the embedded studio can read it if it supports params.
  // Format: #gender=female&height=165&weight=55&waist=68&hip=90&bust=86
  const params = new URLSearchParams();
  params.set('gender', profile.gender);
  params.set('height', String(profile.height_cm));
  params.set('weight', String(profile.weight_kg));
  if (profile.waist_cm) params.set('waist', String(profile.waist_cm));
  if (profile.hip_cm) params.set('hip', String(profile.hip_cm));
  if (profile.bust_cm) params.set('bust', String(profile.bust_cm));
  const iframeSrc = `${STUDIO_URL}#${params.toString()}`;

  const genderLabel = profile.gender === 'female' ? 'Nữ' : 'Nam';

  return (
    <div className={fullscreen ? 'fixed inset-0 z-50 bg-stone-900' : ''}>
      <div
        className={
          fullscreen
            ? 'flex h-screen flex-col'
            : 'rounded-3xl border border-stone-200 bg-white/80 shadow-sm backdrop-blur overflow-hidden'
        }
      >
        {/* Header bar */}
        <div className="flex items-center justify-between gap-2 border-b border-stone-200 bg-white/90 px-4 py-3">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-gradient-to-br from-rose-500 to-amber-500 text-white">
              <span className="text-sm font-bold">3D</span>
            </div>
            <div>
              <h3 className="text-sm font-bold text-stone-800">Studio Ma-nơ-canh 3D</h3>
              <p className="text-xs text-stone-400">
                Ma-nơ-canh {genderLabel} · {profile.height_cm}cm · {profile.weight_kg}kg
                {profile.waist_cm ? ` · ${profile.waist_cm}/${profile.hip_cm}/${profile.bust_cm}` : ''}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <a
              href={STUDIO_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-medium text-stone-600 transition hover:bg-stone-50"
            >
              <ExternalLink className="h-3.5 w-3.5" /> Mở riêng
            </a>
            <button
              onClick={() => setFullscreen((f) => !f)}
              className="flex items-center gap-1.5 rounded-lg border border-stone-200 px-3 py-1.5 text-xs font-medium text-stone-600 transition hover:bg-stone-50"
            >
              {fullscreen ? (
                <>
                  <Minimize2 className="h-3.5 w-3.5" /> Thu nhỏ
                </>
              ) : (
                <>
                  <Maximize2 className="h-3.5 w-3.5" /> Toàn màn
                </>
              )}
            </button>
          </div>
        </div>

        {/* Info banner — gender auto-selected */}
        <div className="flex items-center gap-2 bg-rose-50/70 px-4 py-2 text-xs text-stone-600">
          <Info className="h-3.5 w-3.5 shrink-0 text-rose-400" />
          <span>
            Ma-nơ-canh <strong className="text-rose-600">{genderLabel}</strong> đã được tự động chọn
            dựa trên thông tin của bạn. Bạn có thể tinh chỉnh chiều cao, cân nặng và số đo trực tiếp
            trong studio bên dưới.
          </span>
        </div>

        {/* Iframe container */}
        <div className="relative flex-1 bg-stone-100" style={fullscreen ? { height: '100%' } : { height: '600px' }}>
          <iframe
            src={iframeSrc}
            title="Studio Ma-nơ-canh 3D"
            className="absolute inset-0 h-full w-full border-0"
            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
            allowFullScreen
          />
        </div>
      </div>
    </div>
  );
}

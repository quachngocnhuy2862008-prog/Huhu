import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Profile {
  id: string;
  name: string;
  age: number;
  gender: 'male' | 'female';
  height_cm: number;
  weight_kg: number;
  waist_cm?: number | null;
  hip_cm?: number | null;
  bust_cm?: number | null;
  bmi?: number | null;
  body_type?: string | null;
  created_at?: string;
  user_id?: string;
}

export interface ClothingItem {
  id: string;
  image_path: string;
  category: 'top' | 'bottom' | 'dress' | 'outerwear' | 'other';
  color?: string | null;
  label: string;
  fit_score?: number | null;
  fit_notes?: string | null;
  created_at?: string;
  user_id?: string;
}

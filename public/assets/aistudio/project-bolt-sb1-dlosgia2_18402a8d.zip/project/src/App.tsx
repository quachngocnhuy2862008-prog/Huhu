import { useState, useEffect } from 'react';
import OnboardingScene from '@/components/OnboardingScene';
import Wardrobe from '@/components/Wardrobe';
import type { Occasion } from '@/lib/occasions';
import type { Profile } from '@/lib/supabase';
import { supabase } from '@/lib/supabase';
import { analyzeBody, type RawMeasurements } from '@/lib/bodyAnalysis';

function App() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [occasion, setOccasion] = useState<Occasion>('casual');
  const [restoring, setRestoring] = useState(false);

  // Handle Google OAuth redirect-back: detect session and restore stashed onboarding data
  useEffect(() => {
    (async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) return;

      const stashed = localStorage.getItem('pending_onboarding');
      if (!stashed) return;

      setRestoring(true);
      try {
        const pending = JSON.parse(stashed) as {
          form: {
            name: string;
            age: string;
            gender: 'male' | 'female';
            height: string;
            weight: string;
            waist: string;
            hip: string;
            bust: string;
          };
          analysis: { bmi: number; bodyType: string } | null;
          occasion: Occasion | null;
        };

        const row = {
          name: pending.form.name.trim(),
          age: Number(pending.form.age),
          gender: pending.form.gender,
          height_cm: Number(pending.form.height),
          weight_kg: Number(pending.form.weight),
          waist_cm: pending.form.gender === 'female' ? Number(pending.form.waist) : null,
          hip_cm: pending.form.gender === 'female' ? Number(pending.form.hip) : null,
          bust_cm: pending.form.gender === 'female' ? Number(pending.form.bust) : null,
          bmi: pending.analysis?.bmi ?? null,
          body_type: pending.analysis?.bodyType ?? null,
        };

        const { data, error } = await supabase
          .from('profiles')
          .insert(row)
          .select()
          .maybeSingle();

        localStorage.removeItem('pending_onboarding');

        if (error || !data) {
          setProfile({
            ...row,
            id: crypto.randomUUID(),
            created_at: new Date().toISOString(),
          } as Profile);
        } else {
          setProfile(data as Profile);
        }
        if (pending.occasion) setOccasion(pending.occasion);
      } catch {
        // If restore fails, let user start fresh
        localStorage.removeItem('pending_onboarding');
      }
      setRestoring(false);
    })();
  }, []);

  if (restoring) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-gradient-to-b from-rose-50 via-amber-50 to-sky-50">
        <div className="text-center">
          <div className="mb-3 h-10 w-10 mx-auto animate-spin rounded-full border-4 border-rose-200 border-t-rose-500" />
          <p className="text-stone-600">Đang khôi phục thông tin của bạn...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <OnboardingScene
        onComplete={(p, occ) => {
          setProfile(p);
          setOccasion(occ);
        }}
        onSkip={() => {
          setProfile({
            id: crypto.randomUUID(),
            name: 'Khách',
            age: 25,
            gender: 'female',
            height_cm: 165,
            weight_kg: 55,
            waist_cm: 68,
            hip_cm: 90,
            bust_cm: 86,
            bmi: 20.2,
            body_type: 'hourglass',
            created_at: new Date().toISOString(),
          });
          setOccasion('casual');
        }}
      />
    );
  }

  return <Wardrobe profile={profile} occasion={occasion} onReset={() => setProfile(null)} />;
}

export default App;

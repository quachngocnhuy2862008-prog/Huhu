# ATELIER 3D — Studio Ma-nơ-canh & Thử Trang Phục Thực Tế

Ứng dụng phòng thử đồ 3D tương tác thời gian thực xây dựng trên nền tảng **Three.js**, **React** và **Vite**, cho phép người dùng nhập số đo cơ thể thực tế (chiều cao, cân nặng, số đo các vòng) để tái tạo hình thể ma-nơ-canh như người thật, phối thử các lớp trang phục, tùy chỉnh chất liệu vải (lụa, denim, da, nỉ, cotton) và điều khiển cử động từng khớp xương trên nền trắng studio tinh gọn.

## User Review & Critical Decisions

> [!IMPORTANT]
> Dưới đây là các quyết định thiết kế cốt lõi đã được tổng hợp từ câu trả lời của bạn để đảm bảo trải nghiệm sát thực tế nhất:

- **Hình thể Ma-nơ-canh như người thật theo thông số người dùng**: Ma-nơ-canh được dựng theo tỉ lệ giải phẫu người thật (tùy chọn tông da người thật tự nhiên hoặc bề mặt gốm sứ/thạch cao studio). Khi người dùng nhập **Chiều cao (cm)**, **Cân nặng (kg)**, **Giới tính / Dáng người**, cùng **Độ rộng vai, Vòng ngực, Vòng eo, Vòng hông**, hệ thống tự động tính chỉ số BMI và biến đổi (morph) trực tiếp khung xương, cơ bắp và độ ôm của trang phục theo thời gian thực.
- **Tương tác Cử động Khớp nối & Hoạt ảnh Tự nhiên**: Khi mới mở ứng dụng, người mẫu đứng yên ở tư thế chuẩn tự nhiên trên nền trắng studio. Người dùng có thể **nhấp trực tiếp vào từng khớp trên mô hình 3D** hoặc dùng thanh trượt để xoay góc đầu, cổ, thân trên, vai, khuỷu tay, cổ tay, hông, đầu gối, cổ chân; đồng thời hỗ trợ chuyển đổi mượt mà sang các hoạt ảnh: *Đứng thở tự nhiên (Idle)*, *Đi bộ Catwalk*, *Tạo dáng Lookbook*, và *Xoay 360° kiểm tra độ rủ trang phục*.
- **Trang phục Đa lớp & Chất liệu Vải PBR Thực tế**: Quần áo được gắn trực tiếp vào hệ thống khớp nối (hierarchical bone skinning) nên khi ma-nơ-canh giơ tay, bước đi hay thay đổi cân nặng, trang phục sẽ co giãn và chuyển động theo cơ thể. Hỗ trợ đổi chất liệu vải thực tế (**Lụa bóng nhẹ**, **Denim dệt chéo**, **Da thuộc**, **Len nỉ**, **Cotton**, **Linen**) sử dụng bản đồ bề mặt (normal/roughness map) tạo bằng thuật toán cùng bảng màu thời trang.
- **Giao diện Chuẩn Thiết kế Con người (Figma / 21st.dev Aesthetic)**: Loại bỏ hoàn toàn mọi chi tiết trang trí giả lập AI. Giao diện mang phong cách bàn làm việc thiết kế thời trang chuyên nghiệp (tương tự Figma và Clo3D thu gọn) với nền trắng Studio sáng rõ, thanh công cụ nổi gọn gàng và bảng điều khiển thu gọn được để không che khuất tầm nhìn.

---

## 1. Overview & Core Concept

- **Chức năng chính**: Giúp người mua sắm và nhà thiết kế hình dung chính xác trang phục khi mặc lên đúng vóc dáng cơ thể của chính mình (chiều cao, cân nặng, tỉ lệ vai - ngực - eo - hông) ở mọi góc nhìn 360° và trong nhiều tư thế vận động khác nhau.
- **Đối tượng sử dụng**: Người dùng muốn ướm thử quần áo theo số đo cá nhân trước khi mua, stylist phối đồ đa lớp (layering), hoặc người thiết kế kiểm tra phom dáng và chất liệu vải dưới ánh sáng studio.
- **Giá trị cốt lõi**:
  - **Độ chân thực về tỉ lệ hình thể**: Không chỉ phóng to/thu nhỏ đồng đều, thuật toán phân bổ cân nặng và chiều cao tác động riêng biệt lên chiều dài chân, lưng, độ dày lồng ngực, vòng eo và bắp tay/bắp đùi, kèm gợi ý size trang phục chuẩn xác (S, M, L, XL) và cảnh báo độ chật/rộng ở từng vùng.
  - **Độ chân thực về chất liệu**: Vải lụa có độ óng (`sheen` & `clearcoat`), vải denim có vân dệt chéo rõ nét, vải da có độ phản xạ ánh sáng đặc trưng và vải nỉ có độ nhám bề mặt tự nhiên.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Trạng thái Khởi đầu (Zero-State Studio)**:
   - Ngay khi vào ứng dụng, ma-nơ-canh hình người thực tế đứng yên ở chính giữa không gian 3D nền trắng vô cực (`#F8FAFC`) với bóng đổ mềm mại dưới mặt sàn.
   - Người dùng có thể kéo chuột trái để xoay 360°, lăn chuột để phóng to xem chi tiết đường chỉ/vân vải, hoặc giữ chuột phải để di chuyển góc máy.
2. **Thiết lập Chiều cao, Cân nặng & Số đo Cơ thể (Tab "Số đo & Hình thể")**:
   - Người dùng nhập nhanh **Chiều cao (145 cm – 200 cm)**, **Cân nặng (40 kg – 120 kg)** và chọn **Phom cơ thể (Nam / Nữ / Trung tính)** hoặc chọn nhanh các cấu hình mẫu (*Dáng mảnh*, *Dáng cân đối*, *Dáng thể thao*, *Dáng đầy đặn*).
   - Tinh chỉnh chi tiết: **Độ rộng vai (cm)**, **Vòng ngực (cm)**, **Vòng eo (cm)**, **Vòng hông (cm)**, và **Tông màu da / Bề mặt ma-nơ-canh** (Da sáng, Da tự nhiên, Da ngăm ấm, hoặc Gốm trắng Studio).
   - Hệ thống hiển thị ngay **Gợi ý Size chuẩn (XS – XXL)** và mức độ vừa vặn tại Vai, Ngực, Eo, Hông (*Ôm vừa*, *Thoải mái*, hoặc *Hơi chật*).
3. **Phối đồ & Tùy chỉnh Chất liệu Vải (Tab "Tủ đồ & Chất liệu")**:
   - Chọn kết hợp nhiều lớp trang phục:
     - **Áo trong (Tops)**: Áo thun cổ tròn, Áo sơ mi cài cúc, Áo cổ lọ ôm body, Áo polo.
     - **Áo khoác ngoài (Outerwear)**: Áo Blazer may đo, Áo khoác Bomber, Áo khoác da Biker, Áo Trench Coat dáng dài, hoặc Không mặc áo khoác.
     - **Quần / Chân váy (Bottoms)**: Quần Tây ống suông, Quần Jeans Slim-fit, Quần Cargo túi hộp, Quần Short, Chân váy chữ A.
     - **Giày (Footwear)**: Giày Sneaker trắng tối giản, Giày Boot cổ thấp, Giày Loafer da.
   - Với từng món đồ đang mặc, người dùng chọn **Chất liệu vải thực tế** (*Lụa Silk*, *Vải bò Denim*, *Da thuộc Leather*, *Vải nỉ Wool/Fleece*, *Cotton dệt kim*, *Vải đay Linen*) và **Bảng màu thực tế** cùng độ ôm trang phục (*Slim Fit*, *Regular Fit*, *Oversized*).
4. **Điều khiển Khớp xương & Hoạt ảnh (Tab "Tư thế & Khớp cử động")**:
   - **Chế độ Đứng yên & Tạo dáng sẵn**: *Đứng nghiêm chuẩn (Stand Still)*, *Đứng tự nhiên thả lỏng*, *Chống hông Lookbook*, *Khoanh tay nhẹ*, *Bước đi Catwalk*, *Vẫy tay chào*.
   - **Điều khiển từng khớp xương chi tiết (Joint Rigging)**: Nhấp chọn trực tiếp khớp trên cơ thể 3D (Đầu, Cổ, Cột sống/Thân người, Vai trái/phải, Khuỷu tay trái/phải, Cổ tay, Hông trái/phải, Đầu gối trái/phải, Cổ chân) và kéo thanh trượt góc xoay 3 trục (**Gập/Duỗi X**, **Xoay trục Y**, **Nghiêng Z**) để tạo bất kỳ tư thế nào mong muốn.

### Visual Identity & Theme

- **Aesthetic Direction**: Phong cách **Minimalist Fashion CAD Studio** lấy cảm hứng từ giao diện của **Figma**, **21st.dev** và **CLO3D** — đề cao không gian trắng tinh khiết, đường kẻ mảnh `1px`, chữ số sắc nét và bố cục không che khuất mô hình 3D.
- **Color Palette & Mood**:
  - **Nền 3D Studio (`--background`)**: Trắng xám studio cao cấp (`#F8FAFC` chuyển nhẹ về `#EFF3F8` ở chân trời) giúp làm nổi bật cả trang phục màu trắng lẫn trang phục màu tối.
  - **Bề mặt Bảng điều khiển (`--surface`)**: Trắng tinh khiết (`#FFFFFF`) với viền mảnh `#E2E8F0` và đổ bóng nhẹ.
  - **Màu chữ (`--foreground`)**: Đen than chì `#0F172A` cho tiêu đề, `#475569` cho nhãn thông số.
  - **Điểm nhấn (`--accent`)**: Đen tuyền `#0F172A` cho nút hành động chính và Xanh chàm `#2563EB` cho điểm đánh dấu khớp xương đang được chọn.
- **Typography & Hierarchy**:
  - **Tiêu đề & Thương hiệu**: `Plus Jakarta Sans` (SemiBold 600 / Bold 700).
  - **Nội dung & Nhãn điều khiển**: `DM Sans` (Regular 400 / Medium 500).
  - **Số đo cơ thể & Góc xoay khớp**: `JetBrains Mono` (`tabular-nums`) giúp các con số cm, kg và độ (`°`) thẳng hàng tuyệt đối khi kéo thanh trượt.
- **Layout & Không gian hiển thị**:
  - Giữ toàn bộ vùng trung tâm màn hình thông thoáng 100% cho mô hình 3D.
  - Bảng điều khiển dưới đáy (Collapsible Bottom Dock) tích hợp 3 tab rõ ràng (*Số đo & Hình thể*, *Tủ đồ & Chất liệu*, *Tư thế & Khớp cử động*) có nút thu gọn hoàn toàn (`Ẩn bảng điều khiển`) để xem toàn màn hình.

---

## 3. Key Product Decisions & Trade-Offs

- **Quyết định 1: Mô hình Giải phẫu Đa khớp nối & Trang phục Co giãn theo Xương (Procedural Anatomical Rig & Skinned Garments)**
  - *Giải pháp lựa chọn*: Xây dựng hệ thống ma-nơ-canh giải phẫu 18 khớp nối phân cấp (`THREE.Group` + hình học giải phẫu mượt mà tạo bằng `LatheGeometry` và `ExtrudeGeometry`) kết hợp các lớp trang phục ôm sát từng đoạn cơ thể.
  - *Lý do*: Cho phép biến đổi tức thì chiều cao, cân nặng, độ rộng vai, vòng ngực, vòng eo, vòng hông theo số đo người dùng nhập mà không bị biến dạng méo mó hay lỗi không tải được file 3D bên ngoài; đồng thời trang phục tự động co giãn và cử động khớp hoàn hảo khi xoay tay, chân hay đi bộ.
- **Quyết định 2: Vật liệu Vải Vật lý (PBR `MeshPhysicalMaterial` + Vân vải Canvas 2D)**
  - *Giải pháp lựa chọn*: Tạo trực tiếp các bản đồ vân sợi dệt (normal map & roughness map) cho từng chất liệu (vân chéo của Denim, hạt da của Leather, sợi đan của Len nỉ, độ bóng mịn của Lụa với thuộc tính `sheen` và `clearcoat`) kết hợp hệ thống ánh sáng Studio 3 nguồn (`RoomEnvironment` + Key/Fill/Rim Light).
  - *Lý do*: Mang lại cảm giác nhìn thấy rõ độ sần, độ bóng và nếp gấp vải dưới ánh đèn studio mà không phụ thuộc vào file ảnh bên ngoài.

---

## 4. Technical Architecture & Data Strategy

### Architecture & Component Diagram

```
┌─────────────────────────────────────────────────────────────────────────┐
│                       ATELIER 3D — STUDIO HEADER                        │
│  [ ATELIER 3D ]     Số đo cơ thể · Trang phục · Cử động     [ Đặt lại ] │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│   ┌──────────────────────────┐             ┌────────────────────────┐   │
│   │ Thông số Hình thể & Fit  │             │ Góc máy & Ánh sáng     │   │
│   │ Cao: 172cm · Nặng: 64kg  │             │ [Trước][Nghiêng][Sau]  │   │
│   │ BMI: 21.6 · Size: M      │             │ [Toàn thân][Cận cảnh]  │   │
│   └──────────────────────────┘             └────────────────────────┘   │
│                                                                         │
│                      3D INTERACTIVE STUDIO VIEWPORT                     │
│                (Nền trắng Studio + Sàn đổ bóng tiếp xúc)                │
│                                                                         │
│                         [ Ma-nơ-canh Người Thật ]                       │
│                   ├─ Hệ thống 18 Khớp Xương (Joints)                    │
│                   ├─ Biến hình theo Chiều cao & Cân nặng                │
│                   └─ Lớp Trang phục 3D (Áo, Khoác, Quần, Giày)          │
│                                                                         │
│                     [ ▾ Thu gọn / Mở rộng Bảng điều khiển ]             │
│   ┌─────────────────────────────────────────────────────────────────┐   │
│   │ [ 1. Số đo & Hình thể ] [ 2. Tủ đồ & Chất liệu ] [ 3. Cử động ] │   │
│   ├─────────────────────────────────────────────────────────────────┤   │
│   │ • Thanh trượt Chiều cao, Cân nặng, Vai, Ngực, Eo, Hông          │   │
│   │ • Chọn Áo trong, Áo khoác, Quần, Giày + Vải Lụa/Denim/Da/Nỉ    │   │
│   │ • Chọn Hoạt ảnh (Đứng yên/Catwalk) & Xoay từng khớp tay/chân    │   │
│   └─────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State

- **`BodyMeasurementsState` (Trạng thái Số đo Hình thể)**:
  - `genderProfile`: `'female' | 'male' | 'neutral'`
  - `heightCm`: `145` – `200` (mặc định `170 cm`)
  - `weightKg`: `40` – `120` (mặc định `60 kg`)
  - `shoulderCm`: `34` – `54`, `chestCm`: `74` – `120`, `waistCm`: `56` – `105`, `hipCm`: `78` – `120`
  - `skinTone`: Tông màu da thực tế (Sáng hồng, Tự nhiên, Bánh mật, Nâu ấm) hoặc bề mặt Ma-nơ-canh Studio (Thạch cao trắng, Gốm mờ, Titan).
- **`OutfitConfigurationState` (Trạng thái Trang phục & Chất liệu)**:
  - Quản lý từng lớp trang phục độc lập: `top` (Áo trong), `outerwear` (Áo khoác), `bottom` (Quần/Váy), `footwear` (Giày).
  - Mỗi lớp bao gồm: `styleId` (kiểu dáng), `fabricType` (`'silk' | 'denim' | 'leather' | 'fleece' | 'cotton' | 'linen'`), `colorHex` (màu sắc), `fitEase` (`'slim' | 'regular' | 'oversized'`).
- **`PoseAndJointState` (Trạng thái Cử động & Khớp xương)**:
  - `activePreset`: `'stand_still'` (mặc định đứng yên khi khởi chạy), `'natural_idle'`, `'catwalk'`, `'lookbook_pose'`, `'turn_360'`.
  - `selectedJoint`: Khớp đang được chọn để chỉnh (`'head'`, `'neck'`, `'spine'`, `'leftShoulder'`, `'rightShoulder'`, `'leftElbow'`, `'rightElbow'`, `'leftHip'`, `'rightHip'`, `'leftKnee'`, `'rightKnee'`, ...).
  - `jointRotations`: Bản đồ lưu góc xoay Euler `(x, y, z)` bằng độ (`-180°` đến `180°`) của từng khớp, nội suy mượt mà bằng hàm giảm chấn (`THREE.MathUtils.damp`).

### Interactive Component & State Mapping

- **Tự động quy đổi Cân nặng & Chiều cao sang Hình học 3D**: Khi người dùng thay đổi `heightCm` hoặc `weightKg`, bộ tính toán sinh trắc học sẽ tự động gợi ý hoặc cập nhật tỉ lệ vòng ngực, vòng eo, vòng hông, độ dày cánh tay/đùi và chiều cao tổng thể của ma-nơ-canh, đồng thời co giãn lớp quần áo đang mặc và cập nhật bảng đánh giá độ vừa vặn (Fit Analysis).
- **Tương tác Trực tiếp trên Khung nhìn 3D (Raycasting)**: Nhấp chuột vào bất kỳ bộ phận nào trên ma-nơ-canh (ví dụ: cánh tay phải, đầu, chân trái) sẽ tự động chọn khớp tương ứng và mở ngay thanh trượt chỉnh góc xoay của khớp đó.
- **Chuyển đổi Góc nhìn Camera & Ánh sáng Studio**: Các nút chọn góc máy nhanh (*Chính diện*, *Góc nghiêng 45°*, *Sau lưng*, *Cận cảnh chất liệu áo*) di chuyển camera mượt mà để người dùng quan sát phom dáng và chất liệu vải rõ nét nhất.
